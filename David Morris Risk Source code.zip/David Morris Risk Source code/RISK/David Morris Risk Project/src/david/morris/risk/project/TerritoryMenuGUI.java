/*
Author: David Morris
ID: 201084474
Program: This program is the third year COMP 39X Project for David Morris, this program is based off the game RISK and incorporates its rules and setting.
        The Aim of the game is to conquer all territories on the map as dictated by sections of the world based on real life areas. The players achieve this by deploying
        troops at the start of their turn and then attacking other territories that are adjacent to the ones you own and do not currently control.

Class Description: this is the GUI that displays information of the user about the territories on the game map. it also displays the information of the battles if used to invade
 */

package david.morris.risk.project;

public class TerritoryMenuGUI extends javax.swing.JFrame {

    /**
     * Creates new form TerritoryMenuGUI
     */
    
    int defenderOptions;//variables
    int attacker;
    int defender;
    
    public TerritoryMenuGUI(int at) {//constructor
        
        initComponents();
        int placeholder = at;
        defenderOptions = placeholder;
        getDefenderOptions(at);
        
    }
    
    public void getDefenderOptions(int at){//sets the values of the combo box depending on which territory was selected
        
        defenderOptions = at;
        switch(defenderOptions){
            case 0:
                String[] defendingTerritoryAlaska = {"Northwest Territories","Alberta","Kamchatka"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryAlaska));
                break;
            case 1:
                String[] defendingTerritoryNWT = {"Alaska","Alberta","Ontario","Greenland"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryNWT));
                break;
            case 2:
                String[] defendingTerritoryGreenland = {"Northwest Territories","Ontario","Quebec","Iceland"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryGreenland));
                break;
            case 3:
                String[] defendingTerritoryAlberta = {"Alaska","Northwest Territories","Ontario","Western United States"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryAlberta));
                break;
            case 4:
                String[] defendingTerritoryOntario = {"Northwest Territories","Alberta","Western United States","Eastern United States","Quebec","Greenland"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryOntario));
                break;
            case 5:
                String[] defendingTerritoryQuebec = {"Ontario","Greenland","Eastern United States"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryQuebec));
                break;
            case 6:
                String[] defendingTerritoryWUS = {"Alberta","Ontario","Eastern United States","Central America"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryWUS));
                break;
            case 7:
                String[] defendingTerritoryEUS = {"Ontario","Quebec","Western United States","Central America",};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryEUS));
                break;
            case 8:
                String[] defendingTerritoryCA = {"Western United States","Eastern United States","Venuzuela"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryCA));
                break;
            case 9:
                String[] defendingTerritoryVenuzuela = {"Central America","Peru","Brazil"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryVenuzuela));
                break;
            case 10:
                String[] defendingTerritoryPeru = {"Venizuela","Brazil","Argentina"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryPeru));
                break;
            case 11:
                String[] defendingTerritoryBrazil = {"Venuzuela","Peru","Argentina","North Africa"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryBrazil));
                break;
            case 12:
                String[] defendingTerritoryArgentina = {"Peru","Brazil"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryArgentina));
                break;
            case 13:
                String[] defendingTerritoryIceland = {"Greenland","Scandinavia","Great Britain"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryIceland));
                break;
            case 14:
                String[] defendingTerritoryScandinavia = {"Iceland","Great Britain","Ukraine","Northern Europe"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryScandinavia));
                break;
            case 15:
                String[] defendingTerritoryUK = {"Iceland","Scandinavia","Western Europe","Northern Europe"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryUK));
                break;
            case 16:
                String[] defendingTerritoryNEU = {"Great Britain","Western Europe","Southern Europe","Scandinavia","Ukraine"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryNEU));
                break;
            case 17:
                String[] defendingTerritoryUkraine = {"Scandinavia","Northern Europe","Souhtern Europe","Ural","Afghanistan","Middle East"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryUkraine));
                break;
            case 18:
                String[] defendingTerritoryWEU = {"Great Britain","Northern Europe","Southern Europe","North Africa"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryWEU));
                break;
            case 19:
                String[] defendingTerritorySEU = {"Western Europe","Northern Europe","Ukraine","Middle East","Egypt"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritorySEU));
                break;
            case 20:
                String[] defendingTerritoryNorthAfrica = {"Brazil","Western Europe","Egypt","East Africa","Congo"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryNorthAfrica));
                break;
            case 21:
                String[] defendingTerritoryEgypt = {"Southern Europe","North Africa","Middle East","East Africa"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryEgypt));
                break;
            case 22:
                String[] defendingTerritoryCongo = {"North Africa","East Africa","South Africa"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryCongo));
                break;
            case 23:
                String[] defendingTerritoryEastAfrica = {"Egypt","North Africa","Congo","South Africa","Madagascar","Middle East"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryEastAfrica));
                break;
            case 24:
                String[] defendingTerritorySouthAfrica = {"Congo","East Africa","Madagascar"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritorySouthAfrica));
                break;
            case 25:
                String[] defendingTerritoryMadagascar = {"East Africa","South Africa"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryMadagascar));
                break;
            case 26:
                String[] defendingTerritoryUral = {"Ukraine","Afghanistan","Siberia","China"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryUral));
                break;
            case 27:
                String[] defendingTerritorySiberia = {"Ural","Yakutsk","Irkutsk","China","Mongolia"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritorySiberia));
                break;
            case 28:
                String[] defendingTerritoryYakutsk = {"Siberia","Irkutsk","Katchamka"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryYakutsk));
                break;
            case 29:
                String[] defendingTerritoryKamchatka = {"Yakutsk","Irkutsk","Mongolia","Japan","Alaska"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryKamchatka));
                break;
            case 30:
                String[] defendingTerritoryAfghanistan = {"Ukraine","Middle East","India","China","Ural"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryAfghanistan));
                break;
            case 31:
                String[] defendingTerritoryIrkutsk = {"Siberia","Mongolia","Yakutsk","Katchamka","Japan"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryIrkutsk));
                break;
            case 32:
                String[] defendingTerritoryMongolia = {"Siberia","Irkutsk","Katchamka","Japan","China"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryMongolia));
                break;
            case 33:
                String[] defendingTerritoryChina = {"Ural","Afghanistan","India","Thailand","Siberia","Mongolia"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryChina));
                break;
            case 34:
                String[] defendingTerritoryJapan = {"Katchamka","Mongolia"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryJapan));
                break;
            case 35:
                String[] defendingTerritoryMiddleEast = {"Southern Europe","Ukraine","Afghanistan","India","Egypt","East Africa"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryMiddleEast));
                break;
            case 36:
                String[] defendingTerritoryIndia = {"Middle East","Afghanistan","China","Thailand"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryIndia));
                break;
            case 37:
                String[] defendingTerritoryThailand = {"India","China","Indonesia"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryThailand));
                break;
            case 38:
                String[] defendingTerritoryIndonesia = {"Thailand","New Guinea","Western Australia"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryIndonesia));
                break;
            case 39:
                String[] defendingTerritoryNewGuinea = {"Indonesia","Western Australia","Eastern Australia"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryNewGuinea));
                break;
            case 40:
                String[] defendingTerritoryWAU = {"Indonesia","New Guinea","Eastern Australia"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryWAU));
                break;
            case 41:
                String[] defendingTerritoryEAU = {"New Guinea","Western Australia"};
                invasionTargetBox.setModel(new javax.swing.DefaultComboBoxModel(defendingTerritoryEAU));
                break;
        }
    }

    public void setDiceResults(int d1, int d2, int a1, int a2, int a3){//shows the values of the dice rolls during combat
        
        defenderDiceResult1Txt.setText(Integer.toString(d1));
        defenderDiceResult2Txt.setText(Integer.toString(d2));
        attackerDiceResult1Txt.setText(Integer.toString(a1));
        attackerDiceResult2Txt.setText(Integer.toString(a2));
        attackerDiceResult3Txt.setText(Integer.toString(a3));
    }
    
    public void setTxtBoxValues(String s1, int atkSoldier, int ap, int defSoldier, int dp){//sets information of both attacker and defender to the user
        attacker = ap;
        defender = dp;
        attackerForcesTxt.setText(Integer.toString(atkSoldier));
        defenderForcesTxt.setText(Integer.toString(defSoldier));
        TerritoryNameTxt.setText(s1);
        attackerNameTagTxt.setText("Player " + Integer.toString(ap));
        defenderNameTagTxt.setText("Player " + Integer.toString(dp));
    }
    
    public void setCasualties(int ac, int dc){//displays casualties if battle occurs
        
        attackerCasualtyTxt.setText(Integer.toString(ac));
        defenderCasualtyTxt.setText(Integer.toString(dc));
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        invadeBtn = new javax.swing.JButton();
        invasionTargetBox = new javax.swing.JComboBox<>();
        closeMenuBtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        attackerForcesTxt = new javax.swing.JTextField();
        attackerDiceResult1Txt = new javax.swing.JTextField();
        attackerDiceResult2Txt = new javax.swing.JTextField();
        attackerDiceResult3Txt = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        defenderForcesTxt = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        defenderDiceResult1Txt = new javax.swing.JTextField();
        defenderDiceResult2Txt = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        attackerCasualtyTxt = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        defenderCasualtyTxt = new javax.swing.JTextField();
        TerritoryNameTxt = new javax.swing.JTextField();
        attackerNameTagTxt = new javax.swing.JTextField();
        defenderNameTagTxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        outputBox = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        invadeBtn.setText("Invade");
        invadeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                invadeBtnActionPerformed(evt);
            }
        });

        invasionTargetBox.setModel(invasionTargetBox.getModel());
        invasionTargetBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                invasionTargetBoxActionPerformed(evt);
            }
        });

        closeMenuBtn.setText("close");
        closeMenuBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeMenuBtnActionPerformed(evt);
            }
        });

        jLabel2.setText("Territory Menu");

        jLabel1.setText("Target of Invasion");

        jLabel4.setText("Attackers Forces");

        jLabel5.setText("Dice 1");

        jLabel6.setText("Dice 2");

        jLabel7.setText("Dice 3");

        attackerForcesTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attackerForcesTxtActionPerformed(evt);
            }
        });

        attackerDiceResult1Txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attackerDiceResult1TxtActionPerformed(evt);
            }
        });

        attackerDiceResult2Txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attackerDiceResult2TxtActionPerformed(evt);
            }
        });

        attackerDiceResult3Txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attackerDiceResult3TxtActionPerformed(evt);
            }
        });

        jLabel8.setText("Defenders Forces");

        defenderForcesTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                defenderForcesTxtActionPerformed(evt);
            }
        });

        jLabel9.setText("Dice 1");

        jLabel10.setText("Dice 2");

        defenderDiceResult1Txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                defenderDiceResult1TxtActionPerformed(evt);
            }
        });

        defenderDiceResult2Txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                defenderDiceResult2TxtActionPerformed(evt);
            }
        });

        jLabel11.setText("Attackers lost");

        attackerCasualtyTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attackerCasualtyTxtActionPerformed(evt);
            }
        });

        jLabel12.setText("Defenders Lost");

        defenderCasualtyTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                defenderCasualtyTxtActionPerformed(evt);
            }
        });

        TerritoryNameTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TerritoryNameTxtActionPerformed(evt);
            }
        });

        attackerNameTagTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attackerNameTagTxtActionPerformed(evt);
            }
        });

        defenderNameTagTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                defenderNameTagTxtActionPerformed(evt);
            }
        });

        jLabel3.setText("Attacker");

        jLabel13.setText("Defender");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(closeMenuBtn))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(attackerNameTagTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(303, 303, 303))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(TerritoryNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel1))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel11)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(attackerForcesTxt)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jLabel7))
                                                .addComponent(jLabel5)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel4)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jLabel6))))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(attackerDiceResult2Txt, javax.swing.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE)
                                                    .addComponent(attackerDiceResult1Txt))
                                                .addGap(67, 67, 67)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                            .addComponent(defenderDiceResult1Txt, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(jLabel9))
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                            .addComponent(defenderDiceResult2Txt, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(jLabel10)))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(3, 3, 3)
                                                        .addComponent(defenderCasualtyTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(18, 18, 18)
                                                        .addComponent(jLabel12))))
                                            .addComponent(invasionTargetBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(attackerDiceResult3Txt, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE)
                                                    .addComponent(attackerCasualtyTxt, javax.swing.GroupLayout.Alignment.LEADING))
                                                .addGap(0, 0, Short.MAX_VALUE)))))
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(defenderNameTagTxt)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(defenderForcesTxt, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(invadeBtn, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel13))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(134, 134, 134)
                        .addComponent(outputBox)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(closeMenuBtn)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TerritoryNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(invasionTargetBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(invadeBtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(outputBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(attackerNameTagTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(defenderNameTagTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(attackerDiceResult1Txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(defenderDiceResult1Txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(attackerDiceResult2Txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel10)
                    .addComponent(jLabel6)
                    .addComponent(defenderDiceResult2Txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(attackerForcesTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(attackerDiceResult3Txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(defenderForcesTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(attackerCasualtyTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(defenderCasualtyTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void invasionTargetBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_invasionTargetBoxActionPerformed
        // TODO add your handling code here:
        //outputBox.setText("we did a thing");
        defenderDiceResult1Txt.setText("");//resets text box values after battle
        defenderDiceResult2Txt.setText("");
        attackerDiceResult1Txt.setText("");
        attackerDiceResult2Txt.setText("");
        attackerDiceResult3Txt.setText("");
        attackerCasualtyTxt.setText("");
        defenderCasualtyTxt.setText("");
        
        String selectedOption = (String)invasionTargetBox.getSelectedItem();
        TerritoryClass.defTerritoryName = selectedOption;
        DavidMorrisRiskProject.territoryClass.refreshInfo();
    }//GEN-LAST:event_invasionTargetBoxActionPerformed

    private void invadeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_invadeBtnActionPerformed
        // TODO add your handling code here:
        if(TerritoryClass.currentPlayer == defender){//constraints for battling so other players cannot attack your own territories
            outputBox.setText("You cannot invade a territory you control");
        } else if(TerritoryClass.currentPlayer == attacker){
            String selectedOption = (String)invasionTargetBox.getSelectedItem();
            TerritoryClass.defTerritoryName = selectedOption;
            DavidMorrisRiskProject.territoryClass.getTerritoryInfo();
        } else{//or if you wised to invade using a territory you do not control
            outputBox.setText("You do not control this Territory");
        }
    }//GEN-LAST:event_invadeBtnActionPerformed

    private void closeMenuBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeMenuBtnActionPerformed
        // TODO add your handling code here:
        BattleClass.isBattle = false;
        outputBox.setText("");
        defenderDiceResult1Txt.setText("");//resets values in the text boxes if menu is closed
        defenderDiceResult2Txt.setText("");
        attackerDiceResult1Txt.setText("");
        attackerDiceResult2Txt.setText("");
        attackerDiceResult3Txt.setText("");
        attackerCasualtyTxt.setText("");
        defenderCasualtyTxt.setText("");
        DavidMorrisRiskProject.state = 6;
        DavidMorrisRiskProject.changeScreen();
    }//GEN-LAST:event_closeMenuBtnActionPerformed

    private void defenderDiceResult1TxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_defenderDiceResult1TxtActionPerformed
        // done
    }//GEN-LAST:event_defenderDiceResult1TxtActionPerformed

    private void defenderDiceResult2TxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_defenderDiceResult2TxtActionPerformed
        // done
    }//GEN-LAST:event_defenderDiceResult2TxtActionPerformed

    private void attackerForcesTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attackerForcesTxtActionPerformed
        // done
    }//GEN-LAST:event_attackerForcesTxtActionPerformed

    private void TerritoryNameTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TerritoryNameTxtActionPerformed
        // done
    }//GEN-LAST:event_TerritoryNameTxtActionPerformed

    private void attackerDiceResult1TxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attackerDiceResult1TxtActionPerformed
        // done
    }//GEN-LAST:event_attackerDiceResult1TxtActionPerformed

    private void attackerDiceResult2TxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attackerDiceResult2TxtActionPerformed
        // done
    }//GEN-LAST:event_attackerDiceResult2TxtActionPerformed

    private void attackerDiceResult3TxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attackerDiceResult3TxtActionPerformed
        // done
    }//GEN-LAST:event_attackerDiceResult3TxtActionPerformed

    private void defenderForcesTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_defenderForcesTxtActionPerformed
        // done
    }//GEN-LAST:event_defenderForcesTxtActionPerformed

    private void attackerCasualtyTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attackerCasualtyTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_attackerCasualtyTxtActionPerformed

    private void defenderCasualtyTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_defenderCasualtyTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_defenderCasualtyTxtActionPerformed

    private void attackerNameTagTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attackerNameTagTxtActionPerformed
        // done
    }//GEN-LAST:event_attackerNameTagTxtActionPerformed

    private void defenderNameTagTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_defenderNameTagTxtActionPerformed
        // done
    }//GEN-LAST:event_defenderNameTagTxtActionPerformed

    /**
     * @param args the command line arguments
     */
    public void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TerritoryMenuGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TerritoryMenuGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TerritoryMenuGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TerritoryMenuGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TerritoryMenuGUI(43).setVisible(true);
                
                
                
                
            }
            
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField TerritoryNameTxt;
    private javax.swing.JTextField attackerCasualtyTxt;
    private javax.swing.JTextField attackerDiceResult1Txt;
    private javax.swing.JTextField attackerDiceResult2Txt;
    private javax.swing.JTextField attackerDiceResult3Txt;
    private javax.swing.JTextField attackerForcesTxt;
    private javax.swing.JTextField attackerNameTagTxt;
    private javax.swing.JButton closeMenuBtn;
    private javax.swing.JTextField defenderCasualtyTxt;
    private javax.swing.JTextField defenderDiceResult1Txt;
    private javax.swing.JTextField defenderDiceResult2Txt;
    private javax.swing.JTextField defenderForcesTxt;
    private javax.swing.JTextField defenderNameTagTxt;
    private javax.swing.JButton invadeBtn;
    private javax.swing.JComboBox<String> invasionTargetBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField outputBox;
    // End of variables declaration//GEN-END:variables
}