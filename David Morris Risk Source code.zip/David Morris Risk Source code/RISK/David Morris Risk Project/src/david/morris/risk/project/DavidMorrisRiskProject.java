/*
Author: David Morris
ID: 201084474
Program: This program is the third year COMP 39X Project for David Morris, this program is based off the game RISK and incorporates its rules and setting.
        The Aim of the game is to conquer all territories on the map as dictated by sections of the world based on real life areas. The players achieve this by deploying
        troops at the start of their turn and then attacking other territories that are adjacent to the ones you own and do not currently control.

Class Description: This is the Main Class for the program so it is the entry point when the program is initialised and contains the GUI switch statement which dictates what
                    GUI's are on screen at what time.
 */

package david.morris.risk.project;

public class DavidMorrisRiskProject {//main class
    
    static PlayersGuideMenuGUI playersguidegui = new PlayersGuideMenuGUI();//GUI objects
    static OptionsMenuGUI optionsgui = new OptionsMenuGUI();
    static VideoOptionsMenuGUI videooptionsgui = new VideoOptionsMenuGUI();
    static AudioOptionsMenuGUI audiooptionsgui = new AudioOptionsMenuGUI();
    static MainMenuGUI mainmenugui = new MainMenuGUI();
    static PlayGameMenuGUI playgamegui = new PlayGameMenuGUI();
    static GameMapGUI gamemapgui = new GameMapGUI();
    static TerritoryMenuGUI territorymenugui = new TerritoryMenuGUI(43);
    static ReinforcementGUI reinforcementgui = new ReinforcementGUI();
    static CardHandGUI cardhandgui = new CardHandGUI();
    static WinGUI wingui = new WinGUI();
    
    static DeckClass deckclass = new DeckClass();//class objects
    static GameTurnClass gameTurn = new GameTurnClass();
    static CalcClass calcclass = new CalcClass();
    static UserClass user = new UserClass();
    static PlayerClass player = new PlayerClass();
    static AIClass AI = new AIClass();
    static HumanClass human = new HumanClass();
    static TerritoryClass territoryClass = new TerritoryClass();
    static BattleClass battleclass = new BattleClass();
    
    static int state = 0;//iterator

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {//start of program
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                 changeScreen();//opens gui change method
            }
        });
    }
    
    public static void changeScreen(){//dictates what gui's are visible
        
        if (state == 0){//main menu gui is visible
            mainmenugui.setVisible(true);
            playgamegui.setVisible(false);
            optionsgui.setVisible(false);
            videooptionsgui.setVisible(false);
            audiooptionsgui.setVisible(false);
            playersguidegui.setVisible(false);
            gamemapgui.setVisible(false);
            territorymenugui.setVisible(false);
            cardhandgui.setVisible(false);
            reinforcementgui.setVisible(false); 
            wingui.setVisible(false);
            
        } else if (state == 1){//play game gui is visible
            mainmenugui.setVisible(false);
            playgamegui.setVisible(true);
            optionsgui.setVisible(false);
            videooptionsgui.setVisible(false);
            audiooptionsgui.setVisible(false);
            playersguidegui.setVisible(false);
            gamemapgui.setVisible(false);
            territorymenugui.setVisible(false);
            cardhandgui.setVisible(false);
            reinforcementgui.setVisible(false); 
            wingui.setVisible(false);
            
        } else if (state == 2){//options menu gui is visible
            mainmenugui.setVisible(false);
            playgamegui.setVisible(false);
            optionsgui.setVisible(true);
            videooptionsgui.setVisible(false);
            audiooptionsgui.setVisible(false);
            playersguidegui.setVisible(false);
            gamemapgui.setVisible(false);
            territorymenugui.setVisible(false);
            cardhandgui.setVisible(false);
            reinforcementgui.setVisible(false); 
            wingui.setVisible(false);
            
        } else if (state == 3){//video options menu gui is visible
            mainmenugui.setVisible(false);
            playgamegui.setVisible(false);
            optionsgui.setVisible(false);
            videooptionsgui.setVisible(true);
            audiooptionsgui.setVisible(false);
            playersguidegui.setVisible(false);
            gamemapgui.setVisible(false);
            territorymenugui.setVisible(false);
            cardhandgui.setVisible(false);
            reinforcementgui.setVisible(false); 
            wingui.setVisible(false);
            
        } else if (state == 4){//audio options menu gui is visible
            mainmenugui.setVisible(false);
            playgamegui.setVisible(false);
            optionsgui.setVisible(false);
            videooptionsgui.setVisible(false);
            audiooptionsgui.setVisible(true);
            playersguidegui.setVisible(false);
            gamemapgui.setVisible(false);
            territorymenugui.setVisible(false);
            cardhandgui.setVisible(false);
            reinforcementgui.setVisible(false); 
            wingui.setVisible(false);
            
        } else if (state == 5){//players guide gui is visible
            mainmenugui.setVisible(false);
            playgamegui.setVisible(false);
            optionsgui.setVisible(false);
            videooptionsgui.setVisible(false);
            audiooptionsgui.setVisible(false);
            playersguidegui.setVisible(true);
            gamemapgui.setVisible(false);
            territorymenugui.setVisible(false);
            cardhandgui.setVisible(false);
            reinforcementgui.setVisible(false); 
            wingui.setVisible(false);
            
        } else if (state == 6){//game map gui is visible
            mainmenugui.setVisible(false);
            playgamegui.setVisible(false);
            optionsgui.setVisible(false);
            videooptionsgui.setVisible(false);
            audiooptionsgui.setVisible(false);
            playersguidegui.setVisible(false);
            gamemapgui.setVisible(true);
            territorymenugui.setVisible(false);
            cardhandgui.setVisible(false);
            reinforcementgui.setVisible(false); 
            wingui.setVisible(false);
            
        } else if (state == 7){//territory menu gui is visible on top of game map
            mainmenugui.setVisible(false);
            playgamegui.setVisible(false);
            optionsgui.setVisible(false);
            videooptionsgui.setVisible(false);
            audiooptionsgui.setVisible(false);
            playersguidegui.setVisible(false);
            gamemapgui.setVisible(true);
            territorymenugui.setVisible(true);
            cardhandgui.setVisible(false);
            reinforcementgui.setVisible(false);
            wingui.setVisible(false);
            
        } else if (state == 8){//card hand gui is visible on top of game map
            mainmenugui.setVisible(false);
            playgamegui.setVisible(false);
            optionsgui.setVisible(false);
            videooptionsgui.setVisible(false);
            audiooptionsgui.setVisible(false);
            playersguidegui.setVisible(false);
            gamemapgui.setVisible(true);
            territorymenugui.setVisible(false);
            cardhandgui.setVisible(true);
            reinforcementgui.setVisible(false); 
            wingui.setVisible(false);
            
        } else if (state == 9){//reinforcement gui is visible on top of game map
            mainmenugui.setVisible(false);
            playgamegui.setVisible(false);
            optionsgui.setVisible(false);
            videooptionsgui.setVisible(false);
            audiooptionsgui.setVisible(false);
            playersguidegui.setVisible(false);
            gamemapgui.setVisible(true);
            territorymenugui.setVisible(false);
            cardhandgui.setVisible(false);
            reinforcementgui.setVisible(true);
            wingui.setVisible(false);
            
        } else if (state == 10){//win game gui is visible on top of game map
            mainmenugui.setVisible(false);
            playgamegui.setVisible(false);
            optionsgui.setVisible(false);
            videooptionsgui.setVisible(false);
            audiooptionsgui.setVisible(false);
            playersguidegui.setVisible(false);
            gamemapgui.setVisible(true);
            territorymenugui.setVisible(false);
            cardhandgui.setVisible(false);
            reinforcementgui.setVisible(false);
            wingui.setVisible(true);
        }
    }   
}