/*
Author: David Morris
ID: 201084474
Program: This program is the third year COMP 39X Project for David Morris, this program is based off the game RISK and incorporates its rules and setting.
        The Aim of the game is to conquer all territories on the map as dictated by sections of the world based on real life areas. The players achieve this by deploying
        troops at the start of their turn and then attacking other territories that are adjacent to the ones you own and do not currently control.

Class Description: This is the class of the program that dictates the game order for each player and the turn sequence for each player
 */

package david.morris.risk.project;

public class GameTurnClass {
    
    static String numOfPlayersHolder = "";//string variables
    static String playerType = "";
    
    int turnNumber = 0;//turn number
    
    boolean playerWins = false;//variables
    boolean humanGame;
    static int numOfPlayers;
    static int playerTypeRef;
    static int currentPlayer = 1;
    static int totalTerritories;
    
    int i;//iterator
    
    public void startGame(){//this method starts when the user clicks start game on the start game gui menu
        
        if(playerType.equals("Human")){//checks to see what type of game the user would like to play - if human then the game is "hot-seat" which means multiple players who take turns on one machine
            playerTypeRef = 1;
            if(numOfPlayersHolder.equals("2")){
                numOfPlayers = 2;
                DavidMorrisRiskProject.player.determinePlayers(playerTypeRef, numOfPlayers);
            } else if(numOfPlayersHolder.equals("3")){
                numOfPlayers = 3;
                DavidMorrisRiskProject.player.determinePlayers(playerTypeRef, numOfPlayers);
            } else if(numOfPlayersHolder.equals("4")){
                numOfPlayers = 4;
                DavidMorrisRiskProject.player.determinePlayers(playerTypeRef, numOfPlayers);
            } else if(numOfPlayersHolder.equals("5")){
                numOfPlayers = 5;
                DavidMorrisRiskProject.player.determinePlayers(playerTypeRef, numOfPlayers);
            } else if(numOfPlayersHolder.equals("6")){
                numOfPlayers = 6;
                DavidMorrisRiskProject.player.determinePlayers(playerTypeRef, numOfPlayers);
            }
        } else if(playerType.equals("Computer")){//this is if the user wishes to play alone against a number of AI opponents depending on how many players the user selected
            playerTypeRef = 2;
            if(numOfPlayersHolder.equals("2")){
                numOfPlayers = 2;
                DavidMorrisRiskProject.player.determinePlayers(playerTypeRef, numOfPlayers);
            } else if(numOfPlayersHolder.equals("3")){
                numOfPlayers = 3;
                DavidMorrisRiskProject.player.determinePlayers(playerTypeRef, numOfPlayers);
            } else if(numOfPlayersHolder.equals("4")){
                numOfPlayers = 4;
                DavidMorrisRiskProject.player.determinePlayers(playerTypeRef, numOfPlayers);
            } else if(numOfPlayersHolder.equals("5")){
                numOfPlayers = 5;
                DavidMorrisRiskProject.player.determinePlayers(playerTypeRef, numOfPlayers);
            } else if(numOfPlayersHolder.equals("6")){
                numOfPlayers = 6;
                DavidMorrisRiskProject.player.determinePlayers(playerTypeRef, numOfPlayers);
            }
        }
        
        DavidMorrisRiskProject.deckclass.territoryNum(numOfPlayers, currentPlayer);//distribute cards and territories to players
        DavidMorrisRiskProject.deckclass.territoryDistribution();
        
        DavidMorrisRiskProject.state = 6;//changes GUI state
        DavidMorrisRiskProject.changeScreen();
        
        turnOrder();//starts the first turn
    }    
    
    public void currentPlayer(){//sets the current player for the game
        if(currentPlayer == 1){
            DavidMorrisRiskProject.player.currentPlayer(currentPlayer);//inititalises and load information for this player if it is thier turn
        } else if(currentPlayer == 2){
            DavidMorrisRiskProject.player.currentPlayer(currentPlayer);
        } else if(currentPlayer == 3){
            DavidMorrisRiskProject.player.currentPlayer(currentPlayer);
        } else if(currentPlayer == 4){
            DavidMorrisRiskProject.player.currentPlayer(currentPlayer);
        } else if(currentPlayer == 5){
            DavidMorrisRiskProject.player.currentPlayer(currentPlayer);
        } else if(currentPlayer == 6){
            DavidMorrisRiskProject.player.currentPlayer(currentPlayer);
        }
        DavidMorrisRiskProject.territoryClass.setCurrentPlayer(currentPlayer);
    }
    
    public void getGameState(boolean gs){//gets game state
        humanGame = gs;
    }
    
    public void turnOrder(){
        
        ReinforcementGUI.j = 0;
        currentPlayer();//sets current player
            
        if(humanGame == true){//if versus players
            DavidMorrisRiskProject.territoryClass.getTerritoryOwner();
            DavidMorrisRiskProject.calcclass.reinforcementCalc(currentPlayer);
            DavidMorrisRiskProject.territoryClass.reinforcementTerritories();
            DavidMorrisRiskProject.state = 9;//brings up reinforcement menu
            DavidMorrisRiskProject.changeScreen();
            //when user closes reinforcement menu, user is moved to main gui and can conquer provinces
            //player can select target to invade
            //repeat if player wishes
            //exits program when player clicks end turn
                    
        } else if(humanGame == false){//if versus AI
            if(currentPlayer == 1){//if player is human do this
                DavidMorrisRiskProject.territoryClass.getTerritoryOwner();
                DavidMorrisRiskProject.calcclass.reinforcementCalc(currentPlayer);
                DavidMorrisRiskProject.territoryClass.reinforcementTerritories();
                DavidMorrisRiskProject.state = 9;//brings up reinforcement menu
                DavidMorrisRiskProject.changeScreen();
                //when user closes reinforcement menu, user is moved to main gui and can conquer provinces
                //start conquests
                //player can select nodes
                //exits program when player clicks end turn
            
            } else{//if player is AI do this 
                DavidMorrisRiskProject.territoryClass.getTerritoryOwner();
                DavidMorrisRiskProject.calcclass.reinforcementCalc(currentPlayer);
                DavidMorrisRiskProject.AI.AIGameTurn();
            }
        }
    }
    
    public void endTurn(){//if the user ends the turn 
        
        if(CalcClass.previousTerritories < TerritoryClass.territoryNum){//if player conquers territory draw card at end of turn 
            DavidMorrisRiskProject.deckclass.addCardToHand();
        }
        
        checkWin();//check to see if player wins
        currentPlayer = currentPlayer + 1;//current player moves to next player
        if(currentPlayer > numOfPlayers){//if last player in queue
            currentPlayer = 1;//first player goes
            turnNumber = turnNumber + 1;//turn number increases
        }
        turnOrder();//start next turn
    }
    
    public void checkWin(){
        DavidMorrisRiskProject.player.currentPlayer(currentPlayer);//calculate the number of territories player has
        totalTerritories = TerritoryClass.territoryNum;
        if(totalTerritories == 42){//if player owns 42 territories then they win
            DavidMorrisRiskProject.wingui.setWinner();
            DavidMorrisRiskProject.state = 10;//changes GUI state
        DavidMorrisRiskProject.changeScreen();
        }  // else continue game
    }
}