/*
Author: David Morris
ID: 201084474
Program: This program is the third year COMP 39X Project for David Morris, this program is based off the game RISK and incorporates its rules and setting.
        The Aim of the game is to conquer all territories on the map as dictated by sections of the world based on real life areas. The players achieve this by deploying
        troops at the start of their turn and then attacking other territories that are adjacent to the ones you own and do not currently control.

Class Description: this is the class that holds information regarding the territories and is accessed by alot of classes to retrieve information.
 */

package david.morris.risk.project;

public class TerritoryClass {
    
    /*
    - Key -
    array to territory comparison
    - 0 alaska
    - 1 northwest territories
    - 2 greenland
    - 3 alberta
    - 4 ontario
    - 5 quebec
    - 6 western us
    - 7 eastern us
    - 8 central america
    - 9 venuzuela
    - 10 peru
    - 11 brazil
    - 12 argentina
    - 13 iceland
    - 14 scandinavia
    - 15 UK
    - 16 northern eu
    - 17 ukraine
    - 18 western eu
    - 19 southern eu
    - 20 north africa
    - 21 egypt
    - 22 congo
    - 23 east africa
    - 24 south africa
    - 25 madagascar
    - 26 ural
    - 27 siberia
    - 28 yakutsk
    - 29 kamchatka
    - 30 afghanistan
    - 31 irkutsk
    - 32 mongolia
    - 33 china
    - 34 japan
    - 35 middle east
    - 36 india
    - 37 thailand
    - 38 indonesia
    - 39 new guinea
    - 40 western au
    - 41 eastern au
    */
    
    //rows are territories
    //1st column are references to each territory
    //2nd column is which player is in control
    //3rd column is the number of soldiers in the territory
    
    static int[][] territoryArray = new int [42][3];//territory array
    
    int i = 0;//iterators
    int j = 0;
    int k = 0;
    static int l = 0;
    static int m = 0;
    
    static String atkTerritoryName = "";//string variables
    static String defTerritoryName = "";
    static String reinforcementName = "";
    static String territoryName = "";
    static String selectedReinforcement = "";
    
    static int activeTerritory;//veriables
    static int defendingTerritory;
    static int atkCurrentSoldiers;
    static int defCurrentSoldiers;
    static int atkPlayer;
    static int defPlayer;
    static int territorySelected;
    static int currentPlayer;
    static int territoryNum = 0;
    static int placeholder;
    static int placeholder2;
    static int owner = 0;
    static double placeholder3;
    
    static int america;//region variables
    static int southAmerica;
    static int europe;
    static int africa;
    static int asia;
    static int australasia;
    
    public TerritoryClass(){//constructor
        
        for(int row = 0; row < 42; row++){//this will set values in the first column from 0 to 41
            territoryArray[row][0] = i;
            i++;    
        }
        
        for(int row = 0; row < 42; row++){//this will set all values in the second column to 0
            territoryArray[row][1] = 0;
        }
        
        for(int row = 0; row < 42; row++){//this will set all values in the third column to 2
            territoryArray[row][2] = 2;
        }
    }
    
    static public void displayTerritory(){//calls methods to get information and then displays it to the user
        
        attackingTerritory();
        DavidMorrisRiskProject.territorymenugui.getDefenderOptions(activeTerritory);
        defendingTerritory();
        territoryInfo();
        DavidMorrisRiskProject.territorymenugui.setTxtBoxValues(atkTerritoryName, atkCurrentSoldiers, atkPlayer, defCurrentSoldiers, defPlayer);
    }
    
    static public void refreshInfo(){//calls methods to get information and then displays it to the user
        
        attackingTerritory();
        defendingTerritory();
        territoryInfo();
        DavidMorrisRiskProject.territorymenugui.setTxtBoxValues(atkTerritoryName, atkCurrentSoldiers, atkPlayer, defCurrentSoldiers, defPlayer);
    }
    
    static public void defendingTerritory(){//gets the value from the combo box in the territory GUI 
        
        if(defTerritoryName.equals("Alaska")){
            defendingTerritory = 0;
        }else if(defTerritoryName.equals("Northwest Territories")){
            defendingTerritory = 1;
        }else if(defTerritoryName.equals("Alberta")){
            defendingTerritory = 3;
        }else if(defTerritoryName.equals("Ontario")){
            defendingTerritory = 4;
        }else if(defTerritoryName.equals("Quebec")){
            defendingTerritory = 5;
        }else if(defTerritoryName.equals("Greenland")){
            defendingTerritory = 2;
        }else if(defTerritoryName.equals("Western United States")){
            defendingTerritory = 6;
        }else if(defTerritoryName.equals("Eastern United States")){
            defendingTerritory = 7;
        }else if(defTerritoryName.equals("Central America")){
            defendingTerritory = 8;
        }else if(defTerritoryName.equals("Venuzuela")){
            defendingTerritory = 9;
        }else if(defTerritoryName.equals("Peru")){
            defendingTerritory = 10;
        }else if(defTerritoryName.equals("Brazil")){
            defendingTerritory = 11;
        }else if(defTerritoryName.equals("Argentina")){
            defendingTerritory = 12;
        }else if(defTerritoryName.equals("Iceland")){
            defendingTerritory = 13;
        }else if(defTerritoryName.equals("Scandinavia")){
            defendingTerritory = 14;
        }else if(defTerritoryName.equals("Great Britain")){
            defendingTerritory = 15;
        }else if(defTerritoryName.equals("Ukraine")){
            defendingTerritory = 17;
        }else if(defTerritoryName.equals("Northern Europe")){
            defendingTerritory = 16;
        }else if(defTerritoryName.equals("Southern Europe")){
            defendingTerritory = 19;
        }else if(defTerritoryName.equals("Western Europe")){
            defendingTerritory = 18;
        }else if(defTerritoryName.equals("North Africa")){
            defendingTerritory = 20;
        }else if(defTerritoryName.equals("Egypt")){
            defendingTerritory = 21;
        }else if(defTerritoryName.equals("East Africa")){
            defendingTerritory = 23;
        }else if(defTerritoryName.equals("Congo")){
            defendingTerritory = 22;
        }else if(defTerritoryName.equals("South Africa")){
            defendingTerritory = 24;
        }else if(defTerritoryName.equals("Madagascar")){
            defendingTerritory = 25;
        }else if(defTerritoryName.equals("Ural")){
            defendingTerritory = 26;
        }else if(defTerritoryName.equals("Siberia")){
            defendingTerritory = 27;
        }else if(defTerritoryName.equals("Yakutsk")){
            defendingTerritory = 28;
        }else if(defTerritoryName.equals("Irkutsk")){
            defendingTerritory = 31;
        }else if(defTerritoryName.equals("Kamchatka")){
            defendingTerritory = 29;
        }else if(defTerritoryName.equals("Mongolia")){
            defendingTerritory = 32;
        }else if(defTerritoryName.equals("Afghanistan")){
            defendingTerritory = 30;
        }else if(defTerritoryName.equals("Middle East")){
            defendingTerritory = 35;
        }else if(defTerritoryName.equals("Japan")){
            defendingTerritory = 34;
        }else if(defTerritoryName.equals("China")){
            defendingTerritory = 33;
        }else if(defTerritoryName.equals("India")){
            defendingTerritory = 36;
        }else if(defTerritoryName.equals("Thailand")){
            defendingTerritory = 37;
        }else if(defTerritoryName.equals("Indonesia")){
            defendingTerritory = 38;
        }else if(defTerritoryName.equals("New Guinea")){
            defendingTerritory = 39;
        }else if(defTerritoryName.equals("Western Australia")){
            defendingTerritory = 40;
        }else if(defTerritoryName.equals("Eastern Australia")){
            defendingTerritory = 41;
        }
    }
    
    static public void getTerritoryOwner(){//checks to see who owns what territory
        
        for(l = 0; l <= 41; l++){
            owner = territoryArray[l][1];
            DavidMorrisRiskProject.gamemapgui.checkOwnership(l, owner);
        }
    }
    
    static public void territoryInfo(){//acquires information from the array to put into variables for displaying to the user
        
        atkCurrentSoldiers = territoryArray[activeTerritory][2];
        atkPlayer = territoryArray[activeTerritory][1];
        
        defCurrentSoldiers = territoryArray[defendingTerritory][2];
        defPlayer = territoryArray[defendingTerritory][1];
    }   
    
    static public void changeTerritoryInfo(int aL, int dL){//changes information if troops are lost during a battle and checks to see if territory ownership needs to change
        
        atkCurrentSoldiers = atkCurrentSoldiers - aL;
        if(atkCurrentSoldiers < 1){
            atkCurrentSoldiers = 1;
        }
        territoryArray[activeTerritory][2] = atkCurrentSoldiers;
        
        defCurrentSoldiers = defCurrentSoldiers - dL;
        if(defCurrentSoldiers <= 0){
            territoryArray[activeTerritory][2] = atkCurrentSoldiers - 1;
            defCurrentSoldiers = 1;
            territoryArray[defendingTerritory][1] = currentPlayer;
        } else{
            territoryArray[defendingTerritory][2] = defCurrentSoldiers;
        } 
    }
    
    static public void addTerritoryOwner(int st, int pn){//adds an owner to the territory when they are distributed at the start of the game
        
        if(territoryArray[st][1] == 0){
            if(pn != territoryArray[st][1]){
                territoryArray[st][1] = pn;
            } else if(pn == territoryArray[st][1]){
                DavidMorrisRiskProject.deckclass.chooseTerritory();
            }
            
        } else if(territoryArray[st][1] != 0){
            DavidMorrisRiskProject.deckclass.chooseTerritory();
        }
    }
    
    static public void addSoldiers(int as){//adds soldiers to territories during reinforcement step
        
        defTerritoryName = selectedReinforcement;
        defendingTerritory();
        placeholder = territoryArray[defendingTerritory][2];
        territoryArray[defendingTerritory][2] = placeholder + as;
        CalcClass.reinforcementNum = CalcClass.reinforcementNum - as;
        DavidMorrisRiskProject.calcclass.refreshReinforcementInfo();
    }
    
    static public void calcTerritoryNum(int cpt){//calculates the number of territories owned for game win condition and for reinforcement
        
        territoryNum = 0;
        for(int k = 0; k <= 41; k++){
            if(territoryArray[k][1] == cpt){
                territoryNum = territoryNum + 1;
            }
        }
    }
    
    static public void AITerritory(int ct, int dt){//reinforces territory for the AI
        
        if(territoryArray[ct][1] == currentPlayer){
            placeholder2 = territoryArray[ct][2];
            territoryArray[ct][2] = placeholder2 + dt;
            CalcClass.reinforcementNum = CalcClass.reinforcementNum - dt;
        } else {
            DavidMorrisRiskProject.AI.AITerritorySelect();
        }
    }
    
    static public void AICombat(int ci){//is a part of the combat step for the AI
        if(territoryArray[ci][1] == currentPlayer){
            AIChooseDefender();
        } else{
            DavidMorrisRiskProject.AI.AIConquer();
        }
        
        getTerritoryInfo();
        
    }
    
    static public void AIChooseDefender(){//AI chooses defender for invasion
        placeholder3 = (Math.random() * 42);
        defendingTerritory = (int)placeholder3;
        if(territoryArray[defendingTerritory][1] == currentPlayer){
            AIChooseDefender();
        } 
    }
    
    static public void getTerritoryInfo(){//gets information for battle then ititiates the battle step
        
        territoryInfo();
        DavidMorrisRiskProject.calcclass.battleCalc(atkCurrentSoldiers, defCurrentSoldiers);
    }
      
    static public void attackingTerritory(){
        
        territorySelected = activeTerritory;
        territoryNameSwitch();
        atkTerritoryName = territoryName;  
    }
    
    static public void setCurrentPlayer(int cp){//sets current player
        currentPlayer = cp;
    }
    
    static public void reinforcementTerritories(){//checks to see which territories are able to be reinforced
        for(int j = 0;j <= 41; j++){
            if(currentPlayer == territoryArray[j][1]){
                territorySelected = j;
                territoryNameSwitch();
                reinforcementName = territoryName;
                DavidMorrisRiskProject.reinforcementgui.addReinforcementName(reinforcementName);
            }
        }
        DavidMorrisRiskProject.reinforcementgui.setDropdownBoxValues();
    }
    
    static public void regionOwnership(){//checks to see if someone owns all of a territory
        
        america = 0;
        southAmerica = 0;
        europe = 0;
        africa = 0;
        asia = 0;
        australasia = 0;
        
        for(int m = 0;m <= 41; m++){
            if(currentPlayer == territoryArray[m][1]){
                if(m <= 9){
                    america = america + 1;
                } else if((m > 8) && (m <= 12)){
                    southAmerica = southAmerica + 1;
                } else if((m > 12) && (m <= 19)){
                    europe = europe + 1;
                } else if((m > 19) && (m <= 25)){
                    africa = africa + 1;
                } else if((m > 25) && (m <= 37)){
                    asia = asia + 1;
                } else if((m > 37) && (m <= 41)){
                    australasia = australasia + 1;
                }
            }
        }
    }
    
    static public void territoryNameSwitch(){//displays territory name depending on which territory was selected
    
        switch(territorySelected){
            case 0:
                territoryName = "Alaska";
                break;
            case 1:
                territoryName = "Northwest Territories";
                break;
            case 2:
                territoryName = "Greenland";
                break;
            case 3:
                territoryName = "Alberta";
                break;
            case 4:
                territoryName = "Ontairo";
                break;
            case 5:
                territoryName = "Quebec";
                break;
            case 6:
                territoryName = "Western United States";
                break;
            case 7:
                territoryName = "Eestern United States";
                break;
            case 8:
                territoryName = "Central America";
                break;
            case 9:
                territoryName = "Venuzuela";
                break;
            case 10:
                territoryName = "peru";
                break;
            case 11:
                territoryName = "Brazil";
                break;
            case 12:
                territoryName = "Argentina";
                break;
            case 13:
                territoryName = "Iceland";
                break;
            case 14:
                territoryName = "Scandinavia";
                break;
            case 15:
                territoryName = "United Kingdom";
                break;
            case 16:
                territoryName = "Northern Europe";
                break;
            case 17:
                territoryName = "Ukraine";
                break;
            case 18:
                territoryName = "Western Europe";
                break;
            case 19:
                territoryName = "Southern Europe";
                break;
            case 20:
                territoryName = "North Africa";
                break;
            case 21:
                territoryName = "Egypt";
                break;
            case 22:
                territoryName = "Congo";
                break;
            case 23:
                territoryName = "East Africa";
                break;
            case 24:
                territoryName = "South Africa";
                break;
            case 25:
                territoryName = "Madagascar";
                break;
            case 26:
                territoryName = "Ural";
                break;
            case 27:
                territoryName = "Siberia";
                break;
            case 28:
                territoryName = "Yakutsk";
                break;
            case 29:
                territoryName = "Kamchatka";
                break;
            case 30:
                territoryName = "Afghanistan";
                break;
            case 31:
                territoryName = "Irkutsk";
                break;
            case 32:
                territoryName = "Mongolia";
                break;
            case 33:
                territoryName = "China";
                break;
            case 34:
                territoryName = "Japan";
                break;
            case 35:
                territoryName = "Middle East";
                break;
            case 36:
                territoryName = "India";
                break;
            case 37:
                territoryName = "Siam";
                break;
            case 38:
                territoryName = "Indonesia";
                break;
            case 39:
                territoryName = "New Guinea";
                break;
            case 40:
                territoryName = "Western Australia";
                break;
            case 41:
                territoryName = "Eastern Australia";
                break;
        }        
    }
}