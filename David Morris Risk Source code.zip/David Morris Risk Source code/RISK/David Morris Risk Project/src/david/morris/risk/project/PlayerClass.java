/*
Author: David Morris
ID: 201084474
Program: This program is the third year COMP 39X Project for David Morris, this program is based off the game RISK and incorporates its rules and setting.
        The Aim of the game is to conquer all territories on the map as dictated by sections of the world based on real life areas. The players achieve this by deploying
        troops at the start of their turn and then attacking other territories that are adjacent to the ones you own and do not currently control.

Class Description: this is the parent class for the 2 types of players, human players, and AI players.
 */

package david.morris.risk.project;

public class PlayerClass {
    
    boolean humanPlayer1 = false;//human player variable is set at the start this dictates how many players are in the game
    boolean humanPlayer2 = false;
    boolean humanPlayer3 = false;
    boolean humanPlayer4 = false;
    boolean humanPlayer5 = false;
    boolean humanPlayer6 = false;
    
    boolean computer1 = false;//AI player variable is set at the start this dictates how many players are in the game
    boolean computer2 = false;
    boolean computer3 = false;
    boolean computer4 = false;
    boolean computer5 = false;
    
    boolean humanGame;
    static int playerTotalTerritories = 0;
    
    public void determinePlayers(int pt, int np){//sets the amount of players in the game depending on what option was selected by the user before the game starts
        if(pt == 1){//if all human game
            humanGame = true;
            if(np == 2){
                humanPlayer1 = true;
                humanPlayer2 = true;
            } else if(np == 3){
                humanPlayer1 = true;
                humanPlayer2 = true;
                humanPlayer3 = true;
            } else if(np == 4){
                humanPlayer1 = true;
                humanPlayer2 = true;
                humanPlayer3 = true;
                humanPlayer4 = true;
            } else if(np == 5){
                humanPlayer1 = true;
                humanPlayer2 = true;
                humanPlayer3 = true;
                humanPlayer4 = true;
                humanPlayer5 = true;
            } else if(np == 6){
                humanPlayer1 = true;
                humanPlayer2 = true;
                humanPlayer3 = true;
                humanPlayer4 = true;
                humanPlayer5 = true;
                humanPlayer6 = true;
            }
        } else if(pt == 2){//if versus computer
            humanGame = false;
            if(np == 2){
                humanPlayer1 = true;
                computer1 = true;
            } else if(np == 3){
                humanPlayer1 = true;
                computer1 = true;
                computer2 = true;
            } else if(np == 4){
                humanPlayer1 = true;
                computer1 = true;
                computer2 = true;
                computer3 = true;
            } else if(np == 5){
                humanPlayer1 = true;
                computer1 = true;
                computer2 = true;
                computer3 = true;
                computer4 = true;
            } else if(np == 6){
                humanPlayer1 = true;
                computer1 = true;
                computer2 = true;
                computer3 = true;
                computer4 = true;
                computer5 = true;
            }
        }
        DavidMorrisRiskProject.gameTurn.getGameState(humanGame);
    }
    
    public void currentPlayer(int cp){//sets current player
        if(humanGame == true){
            if(cp == 1){
                DavidMorrisRiskProject.human.humanPlayer1Details();
            } else if(cp == 2){
                DavidMorrisRiskProject.human.humanPlayer2Details();
            } else if(cp == 3){
                DavidMorrisRiskProject.human.humanPlayer3Details();
            } else if(cp == 4){
                DavidMorrisRiskProject.human.humanPlayer4Details();
            } else if(cp == 5){
                DavidMorrisRiskProject.human.humanPlayer5Details();
            } else if(cp == 6){
                DavidMorrisRiskProject.human.humanPlayer6Details();
            }
        } else if(humanGame == false){
            if(cp == 1){
                DavidMorrisRiskProject.human.humanPlayer1Details();
            } else if(cp == 2){
                DavidMorrisRiskProject.AI.computerPlayer1Details();
            } else if(cp == 3){
                DavidMorrisRiskProject.AI.computerPlayer2Details();
            } else if(cp == 4){
                DavidMorrisRiskProject.AI.computerPlayer3Details();
            } else if(cp == 5){
                DavidMorrisRiskProject.AI.computerPlayer4Details();
            } else if(cp == 6){
                DavidMorrisRiskProject.AI.computerPlayer5Details();
            }
        }
    }
}