/*
Author: David Morris
ID: 201084474
Program: This program is the third year COMP 39X Project for David Morris, this program is based off the game RISK and incorporates its rules and setting.
        The Aim of the game is to conquer all territories on the map as dictated by sections of the world based on real life areas. The players achieve this by deploying
        troops at the start of their turn and then attacking other territories that are adjacent to the ones you own and do not currently control.

Class Description: this is the main GUI screen and displays the game map to the user as well as the territory buttons and the card hand and end turn button, as well as a button to 
                    exit the game. the territory buttons open up a small GUI that the user can view information of the territories from that screen.
 */

package david.morris.risk.project;

public class GameMapGUI extends javax.swing.JFrame {

    /**
     * Creates new form GameMapGUI
     */
    public GameMapGUI() {
        initComponents();
    }
    
    //**************************THIS SWITCH STATEMENT IS 600 LINES LONG - PLEASE READ - ***************************//
    // this switch statement is to determine what image the territories are to display based on what player owns the territory
    // this is not optimised because of the nature of netbeans and its nature of accessing certain pieces of information for the GUI
    
    public void checkOwnership(int t, int o){
       switch(t){
           case 0:
               if(o == 1){
                   AlaskaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));//if player 1 owns alaska set image to blue button
               } else if(o == 2){
                   AlaskaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));//if player 2 owns alaska set image to green button
               } else if(o == 3){
                   AlaskaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));//if player 3 owns alaska set image to red button
               } else if(o == 4){
                   AlaskaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));//if player 4 owns alaska set image to pink button
               } else if(o == 5){
                   AlaskaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));//if player 5 owns alaska set image to yellow button
               } else if(o == 6){
                   AlaskaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));//if player 6 owns alaska set image to white button
               }
           case 1:
               if(o == 1){
                   NorthwestTerritoriesBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   NorthwestTerritoriesBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   NorthwestTerritoriesBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   NorthwestTerritoriesBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   NorthwestTerritoriesBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   NorthwestTerritoriesBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 2:
               if(o == 1){
                   GreenlandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   GreenlandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   GreenlandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   GreenlandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   GreenlandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   GreenlandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 3:
               if(o == 1){
                   AlbertaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   AlbertaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   AlbertaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   AlbertaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   AlbertaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   AlbertaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 4:
               if(o == 1){
                   OntarioBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   OntarioBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   OntarioBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   OntarioBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   OntarioBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   OntarioBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 5:
               if(o == 1){
                   QuebecBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   QuebecBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   QuebecBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   QuebecBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   QuebecBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   QuebecBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 6:
               if(o == 1){
                   WesternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   WesternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   WesternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   WesternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   WesternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   WesternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 7:
               if(o == 1){
                   EasternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   EasternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   EasternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   EasternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   EasternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   EasternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 8:
               if(o == 1){
                   CentralAmericaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   CentralAmericaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   CentralAmericaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   CentralAmericaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   CentralAmericaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   CentralAmericaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 9:
               if(o == 1){
                   VenezuelaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   VenezuelaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   VenezuelaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   VenezuelaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   VenezuelaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   VenezuelaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 10:
               if(o == 1){
                   PeruBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   PeruBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   PeruBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   PeruBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   PeruBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   PeruBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 11:
               if(o == 1){
                   BrazilBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   BrazilBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   BrazilBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   BrazilBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   BrazilBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   BrazilBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 12:
               if(o == 1){
                   ArgentinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   ArgentinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   ArgentinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   ArgentinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   ArgentinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   ArgentinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 13:
               if(o == 1){
                   IcelandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   IcelandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   IcelandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   IcelandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   IcelandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   IcelandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 14:
               if(o == 1){
                   ScandanaviaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   ScandanaviaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   ScandanaviaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   ScandanaviaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   ScandanaviaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   ScandanaviaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 15:
               if(o == 1){
                   BritainBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   BritainBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   BritainBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   BritainBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   BritainBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   BritainBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 16:
               if(o == 1){
                   NorthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   NorthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   NorthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   NorthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   NorthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   NorthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 17:
               if(o == 1){
                   UkraineBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   UkraineBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   UkraineBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   UkraineBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   UkraineBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   UkraineBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 18:
               if(o == 1){
                   WesternEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   WesternEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   WesternEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   WesternEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   WesternEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   WesternEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 19:
               if(o == 1){
                   SouthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   SouthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   SouthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   SouthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   SouthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   SouthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 20:
               if(o == 1){
                   NorthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   NorthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   NorthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   NorthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   NorthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   NorthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 21:
               if(o == 1){
                   EgyptBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   EgyptBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   EgyptBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   EgyptBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   EgyptBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   EgyptBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 22:
               if(o == 1){
                   CongoBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   CongoBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   CongoBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   CongoBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   CongoBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   CongoBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 23:
               if(o == 1){
                   EastAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   EastAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   EastAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   EastAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   EastAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   EastAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 24:
               if(o == 1){
                   SouthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   SouthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   SouthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   SouthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   SouthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   SouthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 25:
               if(o == 1){
                   MadagascarBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   MadagascarBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   MadagascarBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   MadagascarBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   MadagascarBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   MadagascarBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 26:
               if(o == 1){
                   UralBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   UralBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   UralBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   UralBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   UralBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   UralBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 27:
               if(o == 1){
                   SiberiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   SiberiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   SiberiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   SiberiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   SiberiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   SiberiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 28:
               if(o == 1){
                   YakutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   YakutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   YakutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   YakutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   YakutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   YakutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 29:
               if(o == 1){
                   KamchatkaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   KamchatkaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   KamchatkaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   KamchatkaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   KamchatkaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   KamchatkaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 30:
               if(o == 1){
                   AfghanistanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   AfghanistanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   AfghanistanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   AfghanistanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   AfghanistanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   AfghanistanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 31:
               if(o == 1){
                   IrkutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   IrkutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   IrkutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   IrkutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   IrkutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   IrkutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 32:
               if(o == 1){
                   MongoliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   MongoliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   MongoliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   MongoliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   MongoliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   MongoliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 33:
               if(o == 1){
                   ChinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   ChinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   ChinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   ChinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   ChinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   ChinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 34:
               if(o == 1){
                   JapanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   JapanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   JapanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   JapanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   JapanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   JapanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 35:
               if(o == 1){
                   MiddleEastBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   MiddleEastBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   MiddleEastBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   MiddleEastBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   MiddleEastBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   MiddleEastBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 36:
               if(o == 1){
                   IndiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   IndiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   IndiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   IndiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   IndiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   IndiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 37:
               if(o == 1){
                   SiamBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   SiamBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   SiamBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   SiamBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   SiamBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   SiamBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 38:
               if(o == 1){
                   IndonesiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   IndonesiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   IndonesiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   IndonesiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   IndonesiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   IndonesiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 39:
               if(o == 1){
                   NewGuineaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   NewGuineaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   NewGuineaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   NewGuineaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   NewGuineaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   NewGuineaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 40:
               if(o == 1){
                   WesternAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   WesternAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   WesternAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   WesternAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   WesternAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   WesternAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
           case 41:
               if(o == 1){
                   EastAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/BlueTeamBtn.png")));
               } else if(o == 2){
                   EastAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/GreenTeamBtn.png")));
               } else if(o == 3){
                   EastAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/RedTeamBtn.png")));
               } else if(o == 4){
                   EastAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/PinkTeamBtn.png")));
               } else if(o == 5){
                   EastAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/YellowTeamBtn.png")));
               } else if(o == 6){
                   EastAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/WhiteTeamBtn.png")));
               }
       }
   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        AfghanistanBtn = new javax.swing.JButton();
        MongoliaBtn = new javax.swing.JButton();
        IndiaBtn = new javax.swing.JButton();
        SouthernEuropeBtn = new javax.swing.JButton();
        IcelandBtn = new javax.swing.JButton();
        GreenlandBtn = new javax.swing.JButton();
        KamchatkaBtn = new javax.swing.JButton();
        WesternUSBtn = new javax.swing.JButton();
        QuebecBtn = new javax.swing.JButton();
        NorthwestTerritoriesBtn = new javax.swing.JButton();
        AlbertaBtn = new javax.swing.JButton();
        SiberiaBtn = new javax.swing.JButton();
        CentralAmericaBtn = new javax.swing.JButton();
        AlaskaBtn = new javax.swing.JButton();
        ChinaBtn = new javax.swing.JButton();
        YakutskBtn = new javax.swing.JButton();
        EgyptBtn = new javax.swing.JButton();
        IrkutskBtn = new javax.swing.JButton();
        NewGuineaBtn = new javax.swing.JButton();
        SiamBtn = new javax.swing.JButton();
        UkraineBtn = new javax.swing.JButton();
        UralBtn = new javax.swing.JButton();
        CongoBtn = new javax.swing.JButton();
        NorthAfricaBtn = new javax.swing.JButton();
        WesternEuropeBtn = new javax.swing.JButton();
        JapanBtn = new javax.swing.JButton();
        ScandanaviaBtn = new javax.swing.JButton();
        NorthernEuropeBtn = new javax.swing.JButton();
        EasternUSBtn = new javax.swing.JButton();
        BrazilBtn = new javax.swing.JButton();
        ArgentinaBtn = new javax.swing.JButton();
        OntarioBtn = new javax.swing.JButton();
        MadagascarBtn = new javax.swing.JButton();
        MiddleEastBtn = new javax.swing.JButton();
        VenezuelaBtn = new javax.swing.JButton();
        SouthAfricaBtn = new javax.swing.JButton();
        BritainBtn = new javax.swing.JButton();
        IndonesiaBtn = new javax.swing.JButton();
        EastAfricaBtn = new javax.swing.JButton();
        EastAustraliaBtn = new javax.swing.JButton();
        PeruBtn = new javax.swing.JButton();
        WesternAustraliaBtn = new javax.swing.JButton();
        mainMenuBtn = new javax.swing.JButton();
        endTurnBtn = new javax.swing.JButton();
        cardHandBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridBagLayout());

        jPanel1.setMaximumSize(new java.awt.Dimension(1680, 1080));
        jPanel1.setMinimumSize(new java.awt.Dimension(1680, 1080));
        jPanel1.setOpaque(false);
        jPanel1.setPreferredSize(new java.awt.Dimension(1680, 1080));

        AfghanistanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        AfghanistanBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AfghanistanBtnActionPerformed(evt);
            }
        });

        MongoliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        MongoliaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MongoliaBtnActionPerformed(evt);
            }
        });

        IndiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        IndiaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IndiaBtnActionPerformed(evt);
            }
        });

        SouthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        SouthernEuropeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SouthernEuropeBtnActionPerformed(evt);
            }
        });

        IcelandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        IcelandBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IcelandBtnActionPerformed(evt);
            }
        });

        GreenlandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        GreenlandBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GreenlandBtnActionPerformed(evt);
            }
        });

        KamchatkaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        KamchatkaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KamchatkaBtnActionPerformed(evt);
            }
        });

        WesternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        WesternUSBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WesternUSBtnActionPerformed(evt);
            }
        });

        QuebecBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        QuebecBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QuebecBtnActionPerformed(evt);
            }
        });

        NorthwestTerritoriesBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        NorthwestTerritoriesBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NorthwestTerritoriesBtnActionPerformed(evt);
            }
        });

        AlbertaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        AlbertaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlbertaBtnActionPerformed(evt);
            }
        });

        SiberiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        SiberiaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SiberiaBtnActionPerformed(evt);
            }
        });

        CentralAmericaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        CentralAmericaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CentralAmericaBtnActionPerformed(evt);
            }
        });

        AlaskaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        AlaskaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlaskaBtnActionPerformed(evt);
            }
        });

        ChinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        ChinaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChinaBtnActionPerformed(evt);
            }
        });

        YakutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        YakutskBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                YakutskBtnActionPerformed(evt);
            }
        });

        EgyptBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        EgyptBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EgyptBtnActionPerformed(evt);
            }
        });

        IrkutskBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        IrkutskBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IrkutskBtnActionPerformed(evt);
            }
        });

        NewGuineaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        NewGuineaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NewGuineaBtnActionPerformed(evt);
            }
        });

        SiamBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        SiamBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SiamBtnActionPerformed(evt);
            }
        });

        UkraineBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        UkraineBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UkraineBtnActionPerformed(evt);
            }
        });

        UralBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        UralBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UralBtnActionPerformed(evt);
            }
        });

        CongoBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        CongoBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CongoBtnActionPerformed(evt);
            }
        });

        NorthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        NorthAfricaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NorthAfricaBtnActionPerformed(evt);
            }
        });

        WesternEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        WesternEuropeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WesternEuropeBtnActionPerformed(evt);
            }
        });

        JapanBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        JapanBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JapanBtnActionPerformed(evt);
            }
        });

        ScandanaviaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        ScandanaviaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ScandanaviaBtnActionPerformed(evt);
            }
        });

        NorthernEuropeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        NorthernEuropeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NorthernEuropeBtnActionPerformed(evt);
            }
        });

        EasternUSBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        EasternUSBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EasternUSBtnActionPerformed(evt);
            }
        });

        BrazilBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        BrazilBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BrazilBtnActionPerformed(evt);
            }
        });

        ArgentinaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        ArgentinaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ArgentinaBtnActionPerformed(evt);
            }
        });

        OntarioBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        OntarioBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OntarioBtnActionPerformed(evt);
            }
        });

        MadagascarBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        MadagascarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MadagascarBtnActionPerformed(evt);
            }
        });

        MiddleEastBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        MiddleEastBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MiddleEastBtnActionPerformed(evt);
            }
        });

        VenezuelaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        VenezuelaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VenezuelaBtnActionPerformed(evt);
            }
        });

        SouthAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        SouthAfricaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SouthAfricaBtnActionPerformed(evt);
            }
        });

        BritainBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        BritainBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BritainBtnActionPerformed(evt);
            }
        });

        IndonesiaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        IndonesiaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IndonesiaBtnActionPerformed(evt);
            }
        });

        EastAfricaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        EastAfricaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EastAfricaBtnActionPerformed(evt);
            }
        });

        EastAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        EastAustraliaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EastAustraliaBtnActionPerformed(evt);
            }
        });

        PeruBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        PeruBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PeruBtnActionPerformed(evt);
            }
        });

        WesternAustraliaBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NeutralTeamBtn.png"))); // NOI18N
        WesternAustraliaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WesternAustraliaBtnActionPerformed(evt);
            }
        });

        mainMenuBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/MainMenuBtn.png"))); // NOI18N
        mainMenuBtn.setText("jButton2");
        mainMenuBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mainMenuBtnActionPerformed(evt);
            }
        });

        endTurnBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/EndTurnBtn.png"))); // NOI18N
        endTurnBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endTurnBtnActionPerformed(evt);
            }
        });

        cardHandBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/HandBtn.png"))); // NOI18N
        cardHandBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardHandBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(699, 699, 699)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(BritainBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(51, 51, 51)
                                .addComponent(NorthernEuropeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(WesternEuropeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(SouthernEuropeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(IcelandBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(62, 62, 62)
                                    .addComponent(ScandanaviaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(NorthAfricaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(522, 522, 522)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(BrazilBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(QuebecBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(383, 383, 383)
                        .addComponent(UkraineBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(364, 364, 364)
                .addComponent(YakutskBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(131, 131, 131)
                .addComponent(KamchatkaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(120, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1714, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(698, 698, 698)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(SouthAfricaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(CongoBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(98, 98, 98)
                                .addComponent(MadagascarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(192, 192, 192)
                                                .addComponent(CentralAmericaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(614, 614, 614))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(EgyptBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(88, 88, 88)))
                                        .addComponent(MiddleEastBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(IndiaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(37, 37, 37))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(151, 151, 151)
                                                        .addComponent(WesternUSBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(105, 105, 105)
                                                        .addComponent(EasternUSBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(250, 250, 250)
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(VenezuelaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addComponent(PeruBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(494, 494, 494)
                                                                .addComponent(EastAfricaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                                .addGap(0, 0, Short.MAX_VALUE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(AlbertaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(AlaskaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(111, 111, 111)
                                                        .addComponent(NorthwestTerritoriesBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(331, 331, 331)
                                                        .addComponent(GreenlandBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(96, 96, 96)
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                            .addComponent(OntarioBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(ArgentinaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                                .addComponent(UralBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(98, 98, 98))
                                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                                .addComponent(AfghanistanBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(127, 127, 127))))))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(cardHandBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(SiamBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(380, 380, 380))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(SiberiaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(419, 419, 419))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(ChinaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(385, 385, 385))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(MongoliaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(78, 78, 78))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(IndonesiaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(IrkutskBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(WesternAustraliaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(126, 126, 126)))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(NewGuineaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JapanBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(EastAustraliaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(173, 173, 173))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(endTurnBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(22, 22, 22))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(mainMenuBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(65, 65, 65))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mainMenuBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(160, 160, 160)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(AlaskaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(NorthwestTerritoriesBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(122, 122, 122)
                                .addComponent(GreenlandBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(YakutskBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(49, 49, 49)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(AlbertaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(QuebecBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(98, 98, 98)
                                                        .addComponent(WesternEuropeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(46, 46, 46)
                                                        .addComponent(WesternUSBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(69, 69, 69)
                                                        .addComponent(CentralAmericaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(OntarioBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(63, 63, 63)
                                                .addComponent(EasternUSBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(UkraineBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(188, 188, 188)
                                                .addComponent(MiddleEastBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(29, 29, 29)
                                        .addComponent(NorthAfricaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(IndiaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(IcelandBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(ScandanaviaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(59, 59, 59)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(NorthernEuropeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(BritainBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(39, 39, 39)
                                            .addComponent(SouthernEuropeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(83, 83, 83)
                                            .addComponent(EgyptBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(100, 100, 100)
                                .addComponent(CongoBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(SouthAfricaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MadagascarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(26, 26, 26)
                                        .addComponent(endTurnBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(126, 126, 126))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cardHandBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(146, 146, 146))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 889, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(11, 11, 11)
                                        .addComponent(UralBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(SiberiaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(VenezuelaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(58, 58, 58)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(BrazilBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(PeruBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(92, 92, 92)
                                        .addComponent(ArgentinaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(279, 279, 279))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(IrkutskBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(23, 23, 23)
                                        .addComponent(MongoliaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(44, 44, 44)
                                        .addComponent(ChinaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(69, 69, 69)
                                        .addComponent(SiamBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(KamchatkaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(901, 901, 901))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(369, 369, 369)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JapanBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(AfghanistanBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(217, 217, 217)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(IndonesiaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(EastAfricaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(245, 245, 245)
                                .addComponent(NewGuineaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(WesternAustraliaBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EastAustraliaBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(279, 279, 279)))
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(124, 124, 124))
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        getContentPane().add(jPanel1, gridBagConstraints);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/david/morris/risk/project/NewGameMap2.jpg"))); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        getContentPane().add(jLabel1, gridBagConstraints);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NorthernEuropeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NorthernEuropeBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 16;//all the territory buttons have the same effect but with a different value depending on which button was clicked
        BattleClass.isBattle = true;
        BattleClass.battleMethod();//start the battle method
    }//GEN-LAST:event_NorthernEuropeBtnActionPerformed

    private void JapanBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JapanBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 34;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_JapanBtnActionPerformed

    private void WesternEuropeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WesternEuropeBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 18;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_WesternEuropeBtnActionPerformed

    private void EgyptBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EgyptBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 21;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_EgyptBtnActionPerformed

    private void ChinaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChinaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 33;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_ChinaBtnActionPerformed

    private void AlbertaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlbertaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 3;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_AlbertaBtnActionPerformed

    private void NorthwestTerritoriesBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NorthwestTerritoriesBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 1;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_NorthwestTerritoriesBtnActionPerformed

    private void WesternUSBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WesternUSBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 6;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_WesternUSBtnActionPerformed

    private void KamchatkaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KamchatkaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 29;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_KamchatkaBtnActionPerformed

    private void IcelandBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IcelandBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 13;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_IcelandBtnActionPerformed

    private void IndiaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IndiaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 36;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_IndiaBtnActionPerformed

    private void AfghanistanBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AfghanistanBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 30;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_AfghanistanBtnActionPerformed

    private void AlaskaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlaskaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 0;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_AlaskaBtnActionPerformed

    private void GreenlandBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GreenlandBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 2;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_GreenlandBtnActionPerformed

    private void OntarioBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OntarioBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 4;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_OntarioBtnActionPerformed

    private void QuebecBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QuebecBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 5;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_QuebecBtnActionPerformed

    private void EasternUSBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EasternUSBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 7;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_EasternUSBtnActionPerformed

    private void CentralAmericaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CentralAmericaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 8;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_CentralAmericaBtnActionPerformed

    private void VenezuelaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VenezuelaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 9;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_VenezuelaBtnActionPerformed

    private void BrazilBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BrazilBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 11;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_BrazilBtnActionPerformed

    private void PeruBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PeruBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 10;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_PeruBtnActionPerformed

    private void ArgentinaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ArgentinaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 12;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_ArgentinaBtnActionPerformed

    private void NorthAfricaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NorthAfricaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 20;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_NorthAfricaBtnActionPerformed

    private void CongoBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CongoBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 22;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_CongoBtnActionPerformed

    private void EastAfricaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EastAfricaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 23;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_EastAfricaBtnActionPerformed

    private void SouthAfricaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SouthAfricaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 24;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_SouthAfricaBtnActionPerformed

    private void MadagascarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MadagascarBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 25;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_MadagascarBtnActionPerformed

    private void ScandanaviaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ScandanaviaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 14;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_ScandanaviaBtnActionPerformed

    private void BritainBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BritainBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 15;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_BritainBtnActionPerformed

    private void UkraineBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UkraineBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 17;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_UkraineBtnActionPerformed

    private void SouthernEuropeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SouthernEuropeBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 19;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_SouthernEuropeBtnActionPerformed

    private void MiddleEastBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MiddleEastBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 35;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_MiddleEastBtnActionPerformed

    private void UralBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UralBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 26;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_UralBtnActionPerformed

    private void SiberiaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SiberiaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 27;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_SiberiaBtnActionPerformed

    private void YakutskBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_YakutskBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 28;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_YakutskBtnActionPerformed

    private void IrkutskBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IrkutskBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 31;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_IrkutskBtnActionPerformed

    private void MongoliaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MongoliaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 32;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_MongoliaBtnActionPerformed

    private void SiamBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SiamBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 37;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_SiamBtnActionPerformed

    private void IndonesiaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IndonesiaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 38;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_IndonesiaBtnActionPerformed

    private void NewGuineaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NewGuineaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 39;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
        
    }//GEN-LAST:event_NewGuineaBtnActionPerformed

    private void WesternAustraliaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WesternAustraliaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 40;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_WesternAustraliaBtnActionPerformed

    private void EastAustraliaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EastAustraliaBtnActionPerformed
        // TODO add your handling code here:
        TerritoryClass.activeTerritory = 41;
        BattleClass.isBattle = true;
        BattleClass.battleMethod();
    }//GEN-LAST:event_EastAustraliaBtnActionPerformed

    private void cardHandBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardHandBtnActionPerformed
        // TODO add your handling code here:
        DavidMorrisRiskProject.deckclass.setCardValues();
        
        DavidMorrisRiskProject.state = 8;
        BattleClass.isBattle = false;
        DavidMorrisRiskProject.changeScreen();        
    }//GEN-LAST:event_cardHandBtnActionPerformed

    private void endTurnBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endTurnBtnActionPerformed
        // TODO add your handling code here:
        DavidMorrisRiskProject.gameTurn.endTurn();//starts the end turn sequence 
    }//GEN-LAST:event_endTurnBtnActionPerformed

    private void mainMenuBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mainMenuBtnActionPerformed
        // TODO add your handling code here:
        DavidMorrisRiskProject.state = 0;//takes the user back to the main menu
        DavidMorrisRiskProject.changeScreen();
    }//GEN-LAST:event_mainMenuBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GameMapGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GameMapGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GameMapGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GameMapGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GameMapGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AfghanistanBtn;
    private javax.swing.JButton AlaskaBtn;
    private javax.swing.JButton AlbertaBtn;
    private javax.swing.JButton ArgentinaBtn;
    private javax.swing.JButton BrazilBtn;
    private javax.swing.JButton BritainBtn;
    private javax.swing.JButton CentralAmericaBtn;
    private javax.swing.JButton ChinaBtn;
    private javax.swing.JButton CongoBtn;
    private javax.swing.JButton EastAfricaBtn;
    private javax.swing.JButton EastAustraliaBtn;
    private javax.swing.JButton EasternUSBtn;
    private javax.swing.JButton EgyptBtn;
    private javax.swing.JButton GreenlandBtn;
    private javax.swing.JButton IcelandBtn;
    private javax.swing.JButton IndiaBtn;
    private javax.swing.JButton IndonesiaBtn;
    private javax.swing.JButton IrkutskBtn;
    private javax.swing.JButton JapanBtn;
    private javax.swing.JButton KamchatkaBtn;
    private javax.swing.JButton MadagascarBtn;
    private javax.swing.JButton MiddleEastBtn;
    private javax.swing.JButton MongoliaBtn;
    private javax.swing.JButton NewGuineaBtn;
    private javax.swing.JButton NorthAfricaBtn;
    private javax.swing.JButton NorthernEuropeBtn;
    private javax.swing.JButton NorthwestTerritoriesBtn;
    private javax.swing.JButton OntarioBtn;
    private javax.swing.JButton PeruBtn;
    private javax.swing.JButton QuebecBtn;
    private javax.swing.JButton ScandanaviaBtn;
    private javax.swing.JButton SiamBtn;
    private javax.swing.JButton SiberiaBtn;
    private javax.swing.JButton SouthAfricaBtn;
    private javax.swing.JButton SouthernEuropeBtn;
    private javax.swing.JButton UkraineBtn;
    private javax.swing.JButton UralBtn;
    private javax.swing.JButton VenezuelaBtn;
    private javax.swing.JButton WesternAustraliaBtn;
    private javax.swing.JButton WesternEuropeBtn;
    private javax.swing.JButton WesternUSBtn;
    private javax.swing.JButton YakutskBtn;
    private javax.swing.JButton cardHandBtn;
    private javax.swing.JButton endTurnBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton mainMenuBtn;
    // End of variables declaration//GEN-END:variables
}