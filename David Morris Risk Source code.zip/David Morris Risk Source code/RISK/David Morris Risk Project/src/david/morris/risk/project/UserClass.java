/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package david.morris.risk.project;

/**
 *
 * @author Dave
 */
public class UserClass {
    static PlayerClass player1 = new HumanClass();
    static PlayerClass player2 = new AIClass();
    static PlayerClass player3 = new AIClass();
    static PlayerClass player4 = new AIClass();
    static PlayerClass player5 = new AIClass();
    static PlayerClass player6 = new AIClass();
    
    
    static PlayerClass playerArray[] = new PlayerClass[6];
    
    public static void userArray(){
        
        playerArray[0] = new HumanClass();
        playerArray[1] = new AIClass();
        playerArray[2] = new AIClass();
        playerArray[3] = new AIClass();
        playerArray[4] = new AIClass();
        playerArray[5] = new AIClass();
        
    }
    
    
    
    
    
}
