/*
Author: David Morris
ID: 201084474
Program: This program is the third year COMP 39X Project for David Morris, this program is based off the game RISK and incorporates its rules and setting.
        The Aim of the game is to conquer all territories on the map as dictated by sections of the world based on real life areas. The players achieve this by deploying
        troops at the start of their turn and then attacking other territories that are adjacent to the ones you own and do not currently control.

Class Description: this is the second child class of PlayerClass and it contains information for each AI player in the game as well as dictate the AI's actions in the turn
 */

package david.morris.risk.project;

public class AIClass extends PlayerClass {
    
    static double placeholder;//placeholder variables
    static double placeholder2;
    
    static int computerPlayerTag = 0;//variables
    static int deployedTroops;
    static int chosenTerritory;
    static int chosenInvasion;
    
    static public void computerPlayer1Details(){//details for computer player 1
        computerPlayerTag = 2;
        
            DavidMorrisRiskProject.territoryClass.calcTerritoryNum(computerPlayerTag);
            playerTotalTerritories = TerritoryClass.territoryNum;
    }
    
    static public void computerPlayer2Details(){//details for computer player 2
        computerPlayerTag = 3;
        
            DavidMorrisRiskProject.territoryClass.calcTerritoryNum(computerPlayerTag);
            playerTotalTerritories = TerritoryClass.territoryNum;
    }
    
    static public void computerPlayer3Details(){//details for computer player 3
        computerPlayerTag = 4;
        
            DavidMorrisRiskProject.territoryClass.calcTerritoryNum(computerPlayerTag);
            playerTotalTerritories = TerritoryClass.territoryNum;
    }
    
    static public void computerPlayer4Details(){//details for computer player 5
        computerPlayerTag = 5;
        
            DavidMorrisRiskProject.territoryClass.calcTerritoryNum(computerPlayerTag);
            playerTotalTerritories = TerritoryClass.territoryNum;
    }
    
    static public void computerPlayer5Details(){//details for computer player 6
        computerPlayerTag = 6;
        
            DavidMorrisRiskProject.territoryClass.calcTerritoryNum(computerPlayerTag);
            playerTotalTerritories = TerritoryClass.territoryNum;
    }
    
    static public void AIGameTurn(){//dictates the AI's game turn
        
        if(CalcClass.reinforcementNum != 0){//if they have more than 0 reinforcements
            AITerritoryDistribution();//reinforce territories owned by the AI player
        }
        
        AIConquer();//conquer territories
        DavidMorrisRiskProject.gameTurn.endTurn();//condition to tell ai when to end turn then call end turn method
    }
    
    static public void AITerritoryDistribution(){//distributes troops in a random amount to a random territory owned by the AI player
        
        placeholder = (Math.random() * CalcClass.reinforcementNum) + 1;//random number between 1 and total reinforcements left to distribute
        deployedTroops = (int)placeholder;
        AITerritorySelect();//select territory to deploy
        
        if(CalcClass.reinforcementNum != 0){
            AITerritoryDistribution();//recall this method if there are reinforcements left to deploy
        } 
    }
    
    static public void AITerritorySelect(){
        
        placeholder2 = (Math.random() * 41);//choose random territory
        chosenTerritory = (int)placeholder2;
        DavidMorrisRiskProject.territoryClass.AITerritory(chosenTerritory, deployedTroops);//check to see if its owned by player and how many troops to deploy
    }
    
    static public void AIConquer(){
        
        placeholder2 = (Math.random() * 41);//chooses a random territory
        chosenInvasion = (int)placeholder2;
        DavidMorrisRiskProject.territoryClass.AICombat(chosenInvasion);//invade the chosen territory
    }
}