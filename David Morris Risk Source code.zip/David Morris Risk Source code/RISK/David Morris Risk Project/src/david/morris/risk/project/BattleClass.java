/*
Author: David Morris
ID: 201084474
Program: This program is the third year COMP 39X Project for David Morris, this program is based off the game RISK and incorporates its rules and setting.
        The Aim of the game is to conquer all territories on the map as dictated by sections of the world based on real life areas. The players achieve this by deploying
        troops at the start of their turn and then attacking other territories that are adjacent to the ones you own and do not currently control.

Class Description: this class brings up the territory GUI and loads the relevant information.
 */

package david.morris.risk.project;

public class BattleClass {
    static boolean isBattle = false;
    
    static public void battleMethod(){
        
            DavidMorrisRiskProject.state = 7;//brings up the territory GUI
            DavidMorrisRiskProject.changeScreen();
            
            DavidMorrisRiskProject.territoryClass.displayTerritory();// display information.     
    }
}