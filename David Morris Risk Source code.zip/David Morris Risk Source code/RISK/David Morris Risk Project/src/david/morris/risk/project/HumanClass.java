/*
Author: David Morris
ID: 201084474
Program: This program is the third year COMP 39X Project for David Morris, this program is based off the game RISK and incorporates its rules and setting.
        The Aim of the game is to conquer all territories on the map as dictated by sections of the world based on real life areas. The players achieve this by deploying
        troops at the start of their turn and then attacking other territories that are adjacent to the ones you own and do not currently control.

Class Description: this is the first child class of the PlayerClass and it contains information for each player and is accessed by the player class 
                    and other methods that require the information located within this class.
 */

package david.morris.risk.project;

public class HumanClass extends PlayerClass {
    
    static int humanPlayerTag = 0;//variable
    
    
    
    static public void humanPlayer1Details(){//details for human player 1
        humanPlayerTag = 1;
        
        DavidMorrisRiskProject.territoryClass.calcTerritoryNum(humanPlayerTag);
        PlayerClass.playerTotalTerritories = TerritoryClass.territoryNum;
    }
    
    static public void humanPlayer2Details(){//details for human player 2
        humanPlayerTag = 2;
        
        DavidMorrisRiskProject.territoryClass.calcTerritoryNum(humanPlayerTag);
        playerTotalTerritories = TerritoryClass.territoryNum;
    }
    
    static public void humanPlayer3Details(){//details for human player 3
        humanPlayerTag = 3;
        
        DavidMorrisRiskProject.territoryClass.calcTerritoryNum(humanPlayerTag);
        playerTotalTerritories = TerritoryClass.territoryNum;
    }
    
    static public void humanPlayer4Details(){//details for human player 4
        humanPlayerTag = 4;
        
        DavidMorrisRiskProject.territoryClass.calcTerritoryNum(humanPlayerTag);
        playerTotalTerritories = TerritoryClass.territoryNum;
    }
    
    static public void humanPlayer5Details(){//details for human player 5
        humanPlayerTag = 5;
        
        DavidMorrisRiskProject.territoryClass.calcTerritoryNum(humanPlayerTag);
        playerTotalTerritories = TerritoryClass.territoryNum;
    }
    
    static public void humanPlayer6Details(){//details for human player 6
        humanPlayerTag = 6;
        
        DavidMorrisRiskProject.territoryClass.calcTerritoryNum(humanPlayerTag);
        playerTotalTerritories = TerritoryClass.territoryNum;
    }
}