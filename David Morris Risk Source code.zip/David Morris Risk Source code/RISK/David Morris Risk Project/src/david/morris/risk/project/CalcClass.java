/*
Author: David Morris
ID: 201084474
Program: This program is the third year COMP 39X Project for David Morris, this program is based off the game RISK and incorporates its rules and setting.
        The Aim of the game is to conquer all territories on the map as dictated by sections of the world based on real life areas. The players achieve this by deploying
        troops at the start of their turn and then attacking other territories that are adjacent to the ones you own and do not currently control.

Class Description: This is the calculation class and it contains the mathematical calculations that the program has to do.
 */

package david.morris.risk.project;

public class CalcClass {
    
    int defendersNum = 0;//variables
    int attackersNum = 0;
    double diceRoll = 0;
    double placeholder;
    static int currentPlayer;
    static int defResult1;
    static int defResult2 = 0;
    static int atkResult1 = 0;
    static int atkResult2 = 0;
    static int atkResult3 = 0;
    static int defLost = 0;
    static int atkLost = 0;
    static int troopsFromTerritories = 0;
    static int troopsFromRegions = 0;
    static int troopsFromCards = 0;
    static int reinforcementNum = 0;
    static int previousTerritories = 0;
    int cardReinforcementCount = 0;
    int cardReinforcementNum = 0;
    int totalTerritories;
    boolean isBattle = true;
    
    public void battleCalc(int atkNum, int defNum){//this is the battle method which just calls other methods for either data aquiring, calculation, and displaying the info to the user
        
            defendersNum = defNum;//get num of defender from object
            attackersNum = atkNum;//get num of attacker from object
            
            diceRollCalc();//calc and compare dice rolls
            casualtyCalc();//calc num of casualties
            DavidMorrisRiskProject.territorymenugui.setCasualties(atkLost, defLost);
            DavidMorrisRiskProject.territoryClass.changeTerritoryInfo(atkLost, defLost);
            DavidMorrisRiskProject.territoryClass.displayTerritory();
            
            defLost = 0;
            atkLost = 0;
            
            
            DavidMorrisRiskProject.territoryClass.displayTerritory();
            
            DavidMorrisRiskProject.territoryClass.getTerritoryOwner();//call function to change territory control
    }
    
    public void casualtyCalc(){//calculates the casualties on each side
        
        
        if((defResult1 < atkResult1) || (defResult1 < atkResult2 && atkResult2 != 0) || (defResult1 < atkResult3 && atkResult3 != 0)){
            defLost = defLost + 1;
        } else if((defResult1 >= atkResult1) || (defResult1 >= atkResult2 && atkResult2 != 0) || (defResult1 >= atkResult3 && atkResult3 != 0)){
            atkLost = atkLost + 1;
        }
        
        if((defResult2 < atkResult1) || (defResult2 < atkResult2 && atkResult2 != 0) || (defResult2 < atkResult3 && atkResult3 != 0)){
            defLost = defLost + 1;
        } else if((defResult2 >= atkResult1) || (defResult2 >= atkResult2 && atkResult2 != 0) || (defResult2 >= atkResult3 && atkResult3 != 0)){
            atkLost = atkLost + 1;
        }
    }
    
    public void reinforcementCalc(int cp){//calculates and displays information to the user for reinforcing owned territories
        currentPlayer = cp;
        troopsFromRegions = 0;
        
        DavidMorrisRiskProject.player.currentPlayer(cp);//calculate the number of territories player has
        totalTerritories = TerritoryClass.territoryNum;
        previousTerritories = TerritoryClass.territoryNum;
        
        if(totalTerritories <= 11){//calculate number of reinforcements player will recieve from territories
            troopsFromTerritories = 3;
        } else {
            placeholder = totalTerritories / 3;
            troopsFromTerritories = (int)placeholder;
        }
        
        DavidMorrisRiskProject.territoryClass.regionOwnership();//add extra bonuses from continents
        
        if(TerritoryClass.america == 9){//if player owns armerica
            troopsFromRegions = troopsFromRegions + 5;
        }
        
        if(TerritoryClass.southAmerica == 4){//if player owns south america
            troopsFromRegions = troopsFromRegions + 2;
        }
        
        if(TerritoryClass.europe == 7){//if player owns europe
            troopsFromRegions = troopsFromRegions + 5;
        }
        
        if(TerritoryClass.africa == 6){//if player owns africa
            troopsFromRegions = troopsFromRegions + 3;
        }
        
        if(TerritoryClass.asia == 12){//if player owns asia
            troopsFromRegions = troopsFromRegions + 7;
        }
        
        if(TerritoryClass.australasia == 4){//if player owns australasia
            troopsFromRegions = troopsFromRegions + 2;
        }
        
        //check if player wishes to cash in cards
        DavidMorrisRiskProject.deckclass.checkHand();
        
        reinforcementNum = troopsFromTerritories + troopsFromRegions + troopsFromCards;//total up num of reinforcements
        
        refreshReinforcementInfo();
    }
    
    public void refreshReinforcementInfo(){//refreshes and displays information to the gui for the user
        DavidMorrisRiskProject.reinforcementgui.setReinforceValues(troopsFromTerritories, troopsFromRegions, troopsFromCards, reinforcementNum, currentPlayer);
    }
    
    public void diceRollCalc(){// rolls dice depending on the number of defenders
        
        if(defendersNum > 0){
            diceRoll = 0;
            diceRoll = (Math.random() * 6) + 1;
            defResult1 =  (int)diceRoll;
        }
        
        if(defendersNum > 2){
            diceRoll = 0;
            diceRoll = (Math.random() * 6) + 1;
            defResult2 = (int)diceRoll;
        }
        
        if(attackersNum > 1){
            diceRoll = 0;
            diceRoll = (Math.random() * 6) + 1;
            atkResult1 = (int)diceRoll;
        }
        
        if(attackersNum == 3){
            diceRoll = 0;
            diceRoll = (Math.random() * 6) + 1;
            atkResult2 = (int)diceRoll;   
        } 
        else if(attackersNum > 3){
            diceRoll = 0;
            diceRoll = (Math.random() * 6) + 1;
            atkResult3 = (int)diceRoll;
        }
        
        DavidMorrisRiskProject.territorymenugui.setDiceResults(defResult1, defResult2, atkResult1, atkResult2, atkResult3);//sends results to gui for the user
    }
}