/*
Author: David Morris
ID: 201084474
Program: This program is the third year COMP 39X Project for David Morris, this program is based off the game RISK and incorporates its rules and setting.
        The Aim of the game is to conquer all territories on the map as dictated by sections of the world based on real life areas. The players achieve this by deploying
        troops at the start of their turn and then attacking other territories that are adjacent to the ones you own and do not currently control.

Class Description: the deck class determines the deck of cards for the game and disributes them to players at the start of the game to 
                    determine what territories each player starts with
 */

package david.morris.risk.project;

public class DeckClass {
    
    static int[][] deckArray = new int [44][2];//array for the deck
    
    static int k1 = 0;//iterators for hands
    static int k2 = 0;
    static int k3 = 0;
    static int k4 = 0;
    static int k5 = 0;
    static int k6 = 0;
        
    int i = 0;//iterators
    int j = 0;
    static int l;
    static int m;
    
    static int soldier;
    static int knight;
    static int cannon;
    static int joker;
        
    static int numOfPlayers;//variables
    static int selectedTerritory;
    static int playerNum;
    static int territoriesDistributed = 0;
    static int addCard;
    static double placeholder = 0;
    static double placeholder2;
    
    static int card1;
    static int card2;
    static int card3;
    static int card4;
    static int card5;
        
    /*
        key
        - 1 = soldier
        - 2 = knight
        - 3 = cannon
        - 4 = wildcard
    */
    
    public DeckClass(){//14 of each card will be soldier, knight, and cannon respecivly, and the last 2 will be wild cards
        
        for(i = 0; i < 14; i++){
            deckArray[i][0] = 1;
        }
        
        for(i = 14; i < 28; i++){
            deckArray[i][0] = 2;
        }
        
        for(i = 28; i < 42; i++){
            deckArray[i][0] = 3;
        }
        
        for(i = 42; i < 43; i++){
            deckArray[i][0] = 4;
        }
        
        for(i = 0; i < 43; i++){
            deckArray[i][1] = 0;
        }
    }
    
    static public void territoryNum(int np, int cp){//acquires current player and number of players in game
        playerNum = cp;
        numOfPlayers = np;
    }
    
    static public void territoryDistribution(){//distributes territories to each player starting with the first
           
        for(int j = 0; j <= 41; j++){
            chooseTerritory();
            playerNum ++;
            if(playerNum > numOfPlayers){
                playerNum = 1;
            }
        }     
    }
    
    static public void chooseTerritory(){//randomly chooses territory and calls method to add thier player number to array
        
        placeholder = (Math.random() * 42);
        selectedTerritory = (int)placeholder;
        
        DavidMorrisRiskProject.territoryClass.addTerritoryOwner(selectedTerritory, playerNum);
    }
    
    static public void addCardToHand(){
        
        placeholder = (Math.random() * 44);
        addCard = (int)placeholder2;
        
        if(GameTurnClass.currentPlayer == 1){
            deckArray[addCard][1] = 1;
            k1++;
        } else if(GameTurnClass.currentPlayer == 2){
            deckArray[addCard][1] = 2;
            k2++;
        } else if(GameTurnClass.currentPlayer == 3){
            deckArray[addCard][1] = 3;
            k3++;
        } else if(GameTurnClass.currentPlayer == 4){
            deckArray[addCard][1] = 4;
            k4++;
        } else if(GameTurnClass.currentPlayer == 5){
            deckArray[addCard][1] = 5;
            k5++;
        } else if(GameTurnClass.currentPlayer == 6){
            deckArray[addCard][1] = 6;
            k6++;
        }
    }
    
    static public void checkHand(){
        
        soldier = 0;
        knight = 0;
        cannon =0;
        joker = 0;   
        
        if(GameTurnClass.currentPlayer == 1){
            for(l = 0; l <= 43; l++){
                if(deckArray[l][0] == 1){
                    soldier++;
                } else if(deckArray[l][0] == 2){
                    knight++;
                } else if(deckArray[l][0] == 3){
                    cannon++;
                } else if(deckArray[l][0] == 4){
                    joker++;
                } 
            }
        } else if(GameTurnClass.currentPlayer == 2){
            for(l = 0; l <= 43; l++){
                if(deckArray[l][0] == 1){
                    soldier++;
                } else if(deckArray[l][0] == 2){
                    knight++;
                } else if(deckArray[l][0] == 3){
                    cannon++;
                } else if(deckArray[l][0] == 4){
                    joker++;
                } 
            }
        } else if(GameTurnClass.currentPlayer == 3){
            for(l = 0; l <= 43; l++){
                if(deckArray[l][0] == 1){
                    soldier++;
                } else if(deckArray[l][0] == 2){
                    knight++;
                } else if(deckArray[l][0] == 3){
                    cannon++;
                } else if(deckArray[l][0] == 4){
                    joker++;
                } 
            }
        } else if(GameTurnClass.currentPlayer == 4){
            for(l = 0; l <= 43; l++){
                if(deckArray[l][0] == 1){
                    soldier++;
                } else if(deckArray[l][0] == 2){
                    knight++;
                } else if(deckArray[l][0] == 3){
                    cannon++;
                } else if(deckArray[l][0] == 4){
                    joker++;
                } 
            }
        } else if(GameTurnClass.currentPlayer == 5){
            for(l = 0; l <= 43; l++){
                if(deckArray[l][0] == 1){
                    soldier++;
                } else if(deckArray[l][0] == 2){
                    knight++;
                } else if(deckArray[l][0] == 3){
                    cannon++;
                } else if(deckArray[l][0] == 4){
                    joker++;
                } 
            }
        } else if(GameTurnClass.currentPlayer == 6){
            for(l = 0; l <= 43; l++){
                if(deckArray[l][0] == 1){
                    soldier++;
                } else if(deckArray[l][0] == 2){
                    knight++;
                } else if(deckArray[l][0] == 3){
                    cannon++;
                } else if(deckArray[l][0] == 4){
                    joker++;
                } 
            }
        }
        
        if((soldier == 3) || (knight == 3) || (cannon == 3)){
            spendCards();
        } else if((soldier == 1) && (knight == 1) && (cannon == 1)){
            spendCards();
        } else if(((soldier == 2) || (knight == 2) || (cannon == 2)) && (joker == 1)){
            spendCards();
        }
    }
    
    static public void spendCards(){
        
        if(m == 0){
            
        } else if(m == 1){
            CalcClass.troopsFromCards = 4;
        } else if(m == 2){
            CalcClass.troopsFromCards = 6;
        } else if(m == 3){
            CalcClass.troopsFromCards = 8;
        } else if(m == 4){
            CalcClass.troopsFromCards = 10;
        } else if(m == 5){
            CalcClass.troopsFromCards = 12;
        } else if(m == 6){
            CalcClass.troopsFromCards = 15;
        } else if(m == 7){
            CalcClass.troopsFromCards = 20;
        } else if(m >= 8){
            CalcClass.troopsFromCards = 25;
        }
        m++;
        
        if(GameTurnClass.currentPlayer == 1){
            k1 = 0;
        } else if(GameTurnClass.currentPlayer == 2){
            k2 = 0;
        } else if(GameTurnClass.currentPlayer == 3){
            k3 = 0;
        } else if(GameTurnClass.currentPlayer == 4){
            k4 = 0;
        } else if(GameTurnClass.currentPlayer == 5){
            k5 = 0;
        } else if(GameTurnClass.currentPlayer == 6){
            k6 = 0;
        }
    }
    
    static public void setCardValues(){
        DavidMorrisRiskProject.cardhandgui.setCardHand(card1, card2, card3, card4, card5);
    }
}