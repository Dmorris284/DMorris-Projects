// JavaScript Document

function changeColor()
{

//if 
//(document.getElementById("changeColor").style.backgroundColor.toString() == 'background-color: #3FF'){

//document.getElementById("changeColor").style.backgroundColor="background-color: #F66";

//} else {
	
//document.getElementById("changeColor").style.backgroundColor="background-color: #3FF";
//}
//}
}