// JavaScript Document

var min=8;// these are the maximum and minimum sizes for the text to go.
var max=18;
function IFS() {
 
   var p = document.getElementsByTagName('p');// this function shows that anything within a "p" tag is changed by the font size function
   for(i=0;i<p.length;i++) {
 
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));
      } else {
 
         var s = 12;// this is the original value for the text size
      }
      if(s!=max) {
 
         s += 1;//this adds a value of 1 to the font size each time it is clicked
      }
      p[i].style.fontSize = s+"px"
 
   }
}
function DFS() {
   var p = document.getElementsByTagName('p');
   for(i=0;i<p.length;i++) {
 
      if(p[i].style.fontSize) {
         var s = parseInt(p[i].style.fontSize.replace("px",""));// this function replaces the current size of the font with the new size depending on the comparison between the original and the new font size
      } else {
 
         var s = 12;
      }
      if(s!=min) {
 
         s -= 1;//this negates a value of 1 to the font size each time it is clicked
      }
      p[i].style.fontSize = s+"px"
 
   }
}
