// JavaScript Document

var type = navigator.appCodeName + "<br \>"
+ navigator.appName + "<br \>"
+ navigator.appVersion + "<br \>"
+ navigator.userAgent + "<br \>"
+ navigator.platform + "<br \>"
+ navigator.cookieEnabled; //defining type

var agent = navigator.userAgent; //defining agent
document.write('<h1>--' + type + '--</h1>'); //testing stage - test var value type
document.write('<h1>--' + agent + '--</h1>'); //testing stage - test var value agent
//document.write('<h1>--' + image + '--</h1>'); //testing stage - test var value image

if (agent.indexOf("Firefox") >= 0) // searching for contents of string - does it 
{ 
    image = '<img src="images/Firefox-logo.png" alt="mozilla">'; // true? display 
}


else if (agent.indexOf ("OPR") >= 0)
{
	image = '<img src="images/operalogo.png" alt="Opera">';
}
	
	
else if (agent.indexOf ("MSIE") >= 0)
{
	image = '<img src="images/Internet_Explorer_7_Logo.png" alt="MSIE">';
}
		
	
else if (agent.indexOf ("Chrome") >= 0)
{
	image = '<img src="images/19d5etu3y9q49jpg" alt="chrome">';
}
	

else {
	image = "sorry you are using an unkown browser type";
}