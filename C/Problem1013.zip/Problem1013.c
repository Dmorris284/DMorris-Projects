#include <stdio.h>
#include <string.h>
int main (void) {
	
	int inputStorage[100];//array
	int recordedMark = 1;//user input variable
	int i = 0;//iterator
	int j;//iterator
	
	int upperMark = 0;
	int middleMark = 0;
	int lowerMark = 0;
	
	while(recordedMark != 0){//while loop for input collecting
		scanf("%d", &recordedMark);//scans input into array
		inputStorage[i] = recordedMark;//puts input into array container
		i = i + 1;//iterator moves up to select new container
	}
	
	for (j = 0; j < i - 1; j++){//for loop to iterate through array
		printf("%d\n", inputStorage[j]);//prints out total contents of array
		
		//sorting method to put results into different boundaries
		if(inputStorage[j] >= 85){//higher boundary
			upperMark = upperMark + 1;
		} else if (inputStorage[j] < 60){//lower boundary
			lowerMark = lowerMark + 1;
		} else {//else put into medium boudary
			middleMark = middleMark + 1;
		}
		
	}
	printf(">= 85: %d\n", upperMark);//print out results
	printf("60 - 84: %d\n", middleMark);
	printf("< 60: %d\n", lowerMark);	
}