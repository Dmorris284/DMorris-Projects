#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

int main(){
	
	double teamID = 0;//team ID'S
	double teamID2 = 0;
	
	double gamesPlayed = 0;//amount of games played
	double gamesPlayed2 = 0;
	
	double i;//iterators
	double j;
	
	double teamScore = 0;//scores for the teams
	double teamScore2 = 0;
	
	double gameAmount = 1;//amount of games played
	
	double teamWin = 0;//wins each team has
	double teamWin2 = 0;
	
	double wins = 0;
	double draw = 0;
	
	double winRatio = 0;//value of ratio of wins/losses
	double winRatioHome = 0;
	double goalDiff = 0;//average goal difference variable
	
	double teamScoreFinal = 0;//total amount of goals scored for team
	double teamScore2Final = 0;
	
	//input
	scanf("%d", &gameAmount);
	printf("the value for game Amount is: %d\n", gameAmount);
	
	while(j <= gameAmount){
		printf("please input home team ID:\n");
		scanf("%d", &teamID);
		
		while(teamID >= 30 && teamID < 0){
			printf("ERROR: TEAM ID DOES NOT EXIST, PLEASE INPUT A VALUE BETWEEN 0 -29: \n");//message
			scanf("%d", &teamID);
		}
		
		gamesPlayed++;
		printf("please input away team ID:\n");
		scanf("%d ", &teamID2);
		
		while(teamID2 >= 30 && teamID2 < 0){
			printf("ERROR: TEAM ID DOES NOT EXIST, PLEASE INPUT A VALUE BETWEEN 0 -29: \n");//message
			scanf("%d", &teamID2);
		}
		
		gamesPlayed2++;
		printf("please input the score for the home team:\n");
		scanf("%d\n", &teamScore);
		teamScoreFinal = teamScoreFinal + teamScore;
		printf("please input the score for the away team:\n");
		scanf("%d\n", &teamScore2);
		teamScore2Final = teamScore2Final + teamScore2;
		
		if(teamScore > teamScore2){
			teamWin++;
		} else if(teamScore < teamScore2){
			teamWin2++;
		} else {
			draw++;
		}
		
		j++;//iterator increase
	}
	
	for(i = 0; i == 29; i++){
		if(teamID == i){//home team
			//calculate stats
			printf("%c", teamID);
			
			//win ratio
			winRatio = wins / gamesPlayed;
			printf("%c", winRatio);
			
			//win on home games
			winRatioHome = wins / gamesPlayed;
			printf("%c", winRatioHome);
			
			//average goal difference
			goalDiff = teamScoreFinal / teamScore2Final;
			printf("%c", goalDiff);
			
		} 
		
		if(teamID2 == i){//away team
			//calculate stats
			printf("%c", teamID2);
			
			//win ratio
			winRatio = wins / gamesPlayed2;
			printf("%c", winRatio);
			
			//win on home games
			winRatioHome = -1;
			printf("%c", winRatioHome);
			
			//average goal difference
			goalDiff = teamScore2Final / teamScoreFinal;
			printf("%c", goalDiff);
		}
		
		i++;//iterator increase
	}
}