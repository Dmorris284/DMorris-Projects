#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

int main(){
	
	double inputStorage[100];//array
	
	int numDimensions = 0;//variables
	double vectorElements;
	double elementSum = 0;
	double normVector = 0;
	double finalVector = 0;
	double placeHolderOne = 0;
	double placeHolderTwo = 0;
	
	double i = 0;//iterators
	int j = 0;
	
	scanf("%d", &numDimensions);//scan vector dimensions
	printf("numDimensions is: %d\n", numDimensions);//print to screen
	
	while(i < numDimensions){
		
		scanf("%f\n", &vectorElements);//user input vector elements
		printf("vectorElements is: %f\n", vectorElements);//print to screen
		
		placeHolderOne = vectorElements;
		placeHolderTwo = (vectorElements * placeHolderOne);//square the value of vector element
		
		printf("placeHolderTwo is: %f\n", placeHolderTwo);//print to screen
		inputStorage[j] = placeHolderTwo;//put element into array
		printf("%f\n", inputStorage[j]);//print to screen
		
		j = j + 1;//increase iterator values
		i = i + 1;
	}
	i = 0;//reset iterator values
	j = 0;
	
	while(i < numDimensions){
		elementSum = elementSum + inputStorage[j];//create element sum
		printf("this is the Element sum: %f\n", elementSum);//print to screen
		
		j = j + 1;//increase iterator values
		i = i + 1;
	}
	
	i = 0;//reset iterator values
	j = 0;
	
	normVector = sqrt(elementSum);//get the square root of sum of elements squared
	printf("this is the normVector: %f\n", normVector);//print to screen
	
	while(i < numDimensions){
		finalVector = inputStorage[j] / normVector;//find normalised values by dividing sum by original element
		printf("%.3f\n", finalVector);//print to screen
		
		i = i + 1;//increase iterator values
		j = j + 1;
	}
}