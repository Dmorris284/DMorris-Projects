#import <Foundation/foundation.h>
#import <Characters/characters.h>
/*
Name: David Morris
Student ID: 201084474
Description: this is a game in which the user enters the program,
and then selects one of the options listed to them.
the user then follows the instructions given on the option pages.
*/

int main (int argc, char *argv[]){

@implementation Game{
    
    Game_Character* mygame;
    int i;//user input
    
- (void) sayHello{//welcome method
    
	NSLog(@"WELCOME TO THE COMP 282 GAME\n");//text output
	NSLog(@"PLEASE SELECT WHAT OPTION YOU WOULD TO CHOOSE:\n");
	NSLog(@"1) CREATE FRIEND\n");
	NSLog(@"2) CREATE FOE\n");
	NSLog(@"3) DISPLAY ALL CHARACTERS\n");
	NSLog(@"4) MEET\n");
	NSLog(@"5) EDIT CHARACTER\n");
	NSLog(@"6) SORT BY STRENGTH\n");
	NSLog(@"7) QUIT\n");
	}

- (void) main{//main method
    
    scanf("%d", i);//request user input
    //the if statement is to decide which option the user has chosen depending on the input
	if(i == 1){
        friendCreation = [[Game_Character alloc] init];
		
	} else if(i == 2){
        foeCreation = [[Game_Character alloc] init];
		
	} else if(i == 3){
        characterArray = [[Game_Character alloc] init];
		
	} else if(i == 4){
		[self meetMethod];
		
	} else if(i == 5){
        editCharacter = [[Game_Character alloc] init];
		
	} else if(i == 6){
        displayStrength = [[Game_Character alloc] init];
		
	} else if(i == 7){
		[self close];
		
    } else {//this recalls the method if the user gives an invalid input
        [self main];
        
    }
  }
    
- (void) close{
	
    exit(0);//exits the program
	
	}
	
- (void) meetMethod{
	//randomly pick 2 characters from array
	//if friend and foe is picked compare strength stats
	//and kill the one with lower
	//if 2 freinds are picked: take the average int value
	//if 2 foes are picked: take the average wrath value
	
	}
}
}
