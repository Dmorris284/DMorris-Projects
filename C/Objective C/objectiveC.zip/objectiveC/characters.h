#import <Foundation/foundation.h>
#import <Main/main.m>
/*
Name: David Morris
Student ID: 201084474
Description:

*/

int Game_Character (int argc, char *argv[]){
    
@implementation character{
    
    Game_Character* myGame =[[Game_Character alloc] init];
    [myGame loggedIn];//link to main class
    
	int strength;//variables
	int intelligence;
	int wrath;
	NSMutableString *name = @"";
	NSMutableString *spell = @"";
    int j;
    int friendorFoe;
    int k;

- (void) friendCreation{//method
    
	character *friendCharacter = ([character alloc] init);
    
	NSLog(@"PLEASE ENTER THE CHARACTERS NAME:\n");
    scanf("%s", name);//request user input
    friendCharacter.name = name;//changes characteristic
    
	NSLog(@"PLEASE ENTER THE CHARACTERS STRENGTH:\n");
    scanf("%d", strength);//request user input
    
    if(strength < 1 || strength > 10){//if variable is below 1 or over 10
        while(strength < 1 || strength > 10){//while it is invalid
            scanf("%d", strength);//request user input
        }
    }
    friendCharacter.strength = strength;//changes characteristic
    
	NSLog(@"PLEASE ENTER THE CHARACTERS INTELLIGENCE:\n");
    scanf("%d", intelligence);
    
    if(intelligence < 1 || intelligence > 10){
        while(intelligence < 1 || intelligence > 10){
            scanf("%d", intelligence);
        }
    }
    friendCharacter.intelligence = intelligence;//changes characteristic
    
	NSLog(@"PLEASE ENTER A SPELL FOR THE CHARACTER:\n");
    scanf("%s", spell);
    friendCharacter.spell = spell;//changes characteristic
    
    friendorFoe = 1;
    
	[characterArray addObject: friendCharacter];//adds object to array
	}
	
- (void) foeCreation{	character *foeCharacter = ([character alloc] init);//method
    
	NSLog(@"PLEASE ENTER THE CHARACTERS NAME:\n");
    scanf("%s", name);
    foeCharacter.name = name;//changes characteristic
    
	NSLog(@"PLEASE ENTER THE CHARACTERS STRENGTH:\n");
    scanf("%d", strength);
    
    if(strength < 1 || strength > 10){
        while(strength < 1 || strength > 10){
            scanf("%d", strength);
        }
    }
    foeCharacter.strength = strength;//changes characteristic
    
	NSLog(@"PLEASE ENTER THE CHARACTERS WRATH:\n");
    scanf("%d", wrath);
    
    if(wrath < 1 || wrath > 10){
        while(wrath < 1 || wrath > 10){
            scanf("%d", wrath);
        }
    }
    foeCharacter.strength = strength;//changes characteristic
    
    friendorFoe = 2;
	
	[characterArray addObject: foeCharacter];//adds object to array
	}

- (void) characterArray{//method
    
    NSMutableArray *characterArray = [NSMutableArray array];//the array
    
    NSLog(@"%@", characterArray);//displays the Array
	}
	
- (void) editCharacter{//method
    
    NSLog(@"%@", characterArray);
    
    scanf("%d",j);
    if(j == characterArray){
        if(friendorFoe = 1){
            printf("%s", name);//displays character info
            printf("%d", strength);
            printf("%d", intelligence);
            printf("%s", spell);
            
            NSLog(@"PLEASE EDIT THE CHARACTERS STRENGTH:\n");
            scanf("%d", strength);
            
            if(strength < 1 || strength > 10){
                while(strength < 1 || strength > 10){
                    scanf("%d", strength);
                }
            }
            friendCharacter.strength = strength;//changes characteristic
            
            NSLog(@"PLEASE EDIT THE CHARACTERS INTELLIGENCE:\n");
            scanf("%d", intelligence);
            
            if(intelligence < 1 || intelligence > 10){
                while(intelligence < 1 || intelligence > 10){
                    scanf("%d", intelligence);
                }
            }
            friendCharacter.intelligence = intelligence;//changes characteristic
            
            NSLog(@"PLEASE EDIT A SPELL FOR THE CHARACTER:\n");
            scanf("%s", spell);
            friendCharacter.spell = spell;//changes characteristic
            
            [characterArray addObject: friendCharacter];//adds object to array
            
        } else if(friendorFoe = 2){
            printf("%s", name);//displays character info
            printf("%d", strength);
            printf("%d", wrath);
            
            NSLog(@"PLEASE EDIT THE CHARACTERS STRENGTH:\n");
            scanf("%d", strength);
            
            if(strength < 1 || strength > 10){
                while(strength < 1 || strength > 10){
                    scanf("%d", strength);
                }
            }
            friendCharacter.strength = strength;//changes characteristic
            
            NSLog(@"PLEASE EDIT THE CHARACTERS WRATH:\n");
            scanf("%d", wrath);
            
            if(wrath < 1 || wrath > 10){
                while(wrath < 1 || wrath > 10){
                    scanf("%d", wrath);
                }
            }
            foeCharacter.strength = strength;//changes characteristic
            
            [characterArray addObject: foeCharacter];//adds object to array
            
        }
    } else if(){
        scanf("%s", k);
        if(k == ""){
            [self main];
        }
    }
	}
    
- (void) displayStrength{//method
    //add a way to sort the characters in order of strength
    //display it  
        
    }
}
}
