//
//  main.m
//  Comp282sheeranAssignment2
//
//  Created by David Morris on 10/05/2018.
//  Copyright © 2018 David Morris. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
