#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

int getInput(int** numArrays);
int getOutput(int* array);

int main(){
	
	int numRows, i;//variable and iterator
	scanf("%d", &numRows);//user input
	
	int** numarrays = malloc(sizeof(char*) * numRows);//malloc
	
	for(i = 0; i < numRows; i++){//for loop
		getInput(&numArrays[i]);//function call
	}
	
	for(i = 1; i <= numRows; i++){//for loop
		getOutput(numArrays[numRows - i]);//function call
	}
}

getInput(int** numArrays){
	
	char userInput;//variables
	int i, arraySize;//iterator and variable
	
	int* arrayStorage;//pointers
	int* pointer;
	
	scanf("%d", &arraySize);//user input
	
	arrayStorage = malloc(sizeof(char) * (arraySize + 1));//malloc
	
	*numArrays = arrayStorage;//setting pointer values
	*arrayStorage = arraySize;
	pointer = arrayStorage + 1;//vale increase
	
	for(i = 0; i < arraySize; i++){//for loop
		scanf("%d", pointer++);//user input
		
	}
}

void getOutput(int* array){
	int i;//iterator
	int arraySize = *arrayStorage;//variable
	arrayStorage++;//increase by 1
	
	for(i = 0; i < arraySize; i++){//for loop
		printf("%d",arrayStorage[arraySize - 1 - i]);//print to screen
	}
	printf("\n");//print to screen
}