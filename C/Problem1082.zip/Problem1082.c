#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

int main() {
	
	int listLength = 0;
	char oddOrEven;
	int intInput = 0;
	int inputStorage[];
	int i = 0;
	int j = 0;
	int numberHolder = 0;
	
	scanf("%s\n", &oddOrEven);
	while(oddOrEven != odd && even){
		
	}
	
	scanf("%d\n", &listLength);
	
	while(i < listLength){
		scanf("%d\n", &input);
		inputStorage[i] = input;
		i = i + 1;		
	}
	
	if(oddOrEven == odd){
		
		while(j < listLength){
			if(inputStorage[j] % 2){
				j++;
			} else {
				if(numberHolder < inputStorage[j]){
					numberHolder = inputStorage[j];
					printf("%d ", numberHolder);
					j++;
				}
			}
		}
		
	} else if(oddOrEven == even){
		
		while(j < listLength){
			if(inputStorage[j] % 2){
				if(numberHolder < inputStorage[j]){
				numberHolder = inputStorage[j];
				printf("%d ", numberHolder);
				j++;
				
				} else {
				j++;
				
				}
			}
		}
	}
}