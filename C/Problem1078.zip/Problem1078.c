#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

bool isPrime (int num);

int main (){//seperate string into individual characters for manipulation
	
	printf("WELCOME TO THE PROBLEM 1078 PROGRAM, PLEASE ENTER INPUT: \n");
	char inputStorage[1000];//array
	char finalArray[100];
	int i = 0;//iterator variables
	int k = 0;
	int m = 0;
	scanf("%s", &inputStorage);//scan user input

	while(inputStorage[i] != '\0'){//go through string to check prime locations
		
		if(i == 0){//number equals zero
			i++;
			
		} else if(i == 1){//number equals one
			i++;
			
		} else if(isPrime(i) == true){//if value is prime
			i++;
			
		} else {//if number is not prime, print out to screen
			printf("%c", inputStorage[i]);
			i++;

			}
		}
	
	return 0;
}

bool isPrime (int num) {//check which positions are prime
	
	int primeChecker = 1;//amount of numbers that are divisible into the value
	int j;//iterator
	
	for(j = 1; j <= num; j++){//loop iterates up to value being compared
		if(j <= num){	
			if(primeChecker > 2){//if amount of numbers that fo into value is more than 2 
				return false;//number is not prime
				
			} else if(num % j == 0){//if j goes into num with no remainder
				primeChecker++;//add 1 to the value of amount of numbers divisible 
				
				if(num == j){//if the number is the same as the iterator value
					if(primeChecker == 2){//and the amount of numbers that go into num is exactly 2
						return true;//then number is prime
					}
				}
			}
		}
	}	
}