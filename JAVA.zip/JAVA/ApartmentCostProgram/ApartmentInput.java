+/* Author: David Morris
ID:201084474
Program: Apartment rental costs
Purpose: the purpose of this program is to calculate costs for the size of
		 an apartment. this takes into account the size of the apartment and
		 the VAT costs.
*/
import java.util.*;

public class ApartmentInput{
	double length = 0;
	double width = 0;
	
		public static void main (String[]args){
			Scanner input = new Scanner(System.in);
			System.out.println("Welcome to the Apartment Area Program\nPlease enter the dimensions for the apartment:");
			System.out.println("please enter the width of your apartment room");
			double width = input.nextDouble();
			System.out.println("please enter the length of your apartment room");
			double length = input.nextDouble();
			System.out.println("Here are the costs for the floor fitting of your room:");
			
			ApartmentCalc apartment = new ApartmentCalc(length, width);
			System.out.println("Floor area: " + apartment.getFloorArea());
			System.out.println("Floor area cost: " + apartment.getFloorAreaCost());
			System.out.println("Service charge: " + apartment.getServiceCharge());
			System.out.println("VAT: " + apartment.getVAT());
			System.out.println("Cost before VAT: " + apartment.getCostBeforeVAT());
			System.out.println("Total cost: " + apartment.getTotalCost());
		}
}