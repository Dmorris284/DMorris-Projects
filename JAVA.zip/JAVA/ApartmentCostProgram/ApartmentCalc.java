/* Author: David Morris
ID:201084474
Program: Apartment rental costs
Purpose: the purpose of this program is to calculate costs for the size of
		 an apartment. this takes into account the size of the apartment and
		 the VAT costs.
*/
public class ApartmentCalc{
	
	public ApartmentCalc(double len, double wid) {
		length = len;
		width = wid;
		areaCalc();
		costCalc();
		serviceChargeCalc();
		costBeforeVATCalc();
		calcVAT();
		totalCostCalc();
		
	}
	
	private double floorArea = 0.0;
	private double floorAreaCost = 0.0;
	private double serviceCharge = 0.0;
	private double VAT = 0.0;
	private double costBeforeVAT = 0.0;
	private double totalCost = 0.0;
	private double length = 0.0;
	private double width = 0.0;
	
		public double getFloorArea() {
			return floorArea;
		}
	
		public double getFloorAreaCost(){
			return floorAreaCost;
		}
	
		public double getServiceCharge(){
			return serviceCharge;
		}
		
		public double getVAT(){
			return VAT;
		}
	
		public double getCostBeforeVAT(){
			return costBeforeVAT;
		}
	
		public double getTotalCost(){
			return totalCost;
		}
	
			public double areaCalc(){
				return floorArea = length*width;		
			}
	
			public double costCalc(){
				return floorAreaCost = floorArea*6.50;
			}
	
			public double serviceChargeCalc(){
				return serviceCharge = 12.50 + (floorArea/10);
			}
	
			public double calcVAT(){
				return VAT = costBeforeVAT*0.2;
			}
	
			public double costBeforeVATCalc(){
				return costBeforeVAT = floorAreaCost + serviceCharge;
			}
	
			public double totalCostCalc(){
				return totalCost = costBeforeVAT + VAT;
			}
	
}		 