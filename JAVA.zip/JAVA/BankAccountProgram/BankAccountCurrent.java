/* Author: David Morris
ID:201084474
Program: Bank Account Management Program
Purpose: the purpose of this program is to create a simple bank account system to allow a user to view,
deposit and widthdraw values in the account, of which there are 3 types of accounts, basic, current,
and savings. then the program will display the details on screen to the user.
*/

public class BankAccountCurrent extends BankAccountBasic {//clas
	
	protected boolean debitCard = false;//variable
	protected double overdraftLimit = 200.0;//variable
	protected double newBalanceCurrent = 0.0;//variable
	
	public BankAccountCurrent(double wic, double dec){//constructor
		widthdrawAmountCurrent = wic;
		depositAmountCurrent = dec;
		debitCardCalc();//method  call
		overdraftCalc();//method  call
		balanceCalc();//method  call
		widthdrawCalc();//method  call
		depositCalc();//method  call
		newBalanceCalc();//method  call
	}
	
	private double widthdrawAmountCurrent = 0.0;//variable
	private double depositAmountCurrent = 0.0;//variable
	private double newBalanceCurrentWidthdraw = 0.0;//variable
	private double newBalanceCurrentDeposit = 0.0;//variable
	
		public boolean getDebitCard(){//get method
			return debitCard;
		}
		
		public double getOverdraft(){//get method
			return overdraftLimit;
		}
		
		public double getBalanceC(){//get method
			return balance;
		} 
		
		public double getNewBalanceC(){//get method
			return newBalanceCurrent;
		}
		
			public boolean debitCardCalc(){//method
				return debitCard;
			}
			
			public double overdraftCalc(){//method
				return overdraftLimit;
			}
			
			public double balanceCalc(){//mehtod
				return balance;
			}
			
			public double widthdrawCalc(){//method
				
				System.out.printf("You have withdrawn from your current account: $%.2f\n", widthdrawAmountCurrent); //message
				return newBalanceCurrentWidthdraw = ((balance + overdraftLimit) + widthdrawAmountCurrent);//calculation
			}
			
			public double depositCalc(){
				System.out.printf("You have deposited into your current account: $%.2f\n", depositAmountCurrent); //message
				return newBalanceCurrentDeposit = (balance + overdraftLimit) + depositAmountCurrent;//calculation
			}
			
			public double newBalanceCalc(){
				if (widthdrawAmountCurrent > 0) {//IF parameter
					System.out.printf("You have been charged the account fee of: $15.00"); //message
					return newBalanceCurrent = ((balance + overdraftLimit + newBalanceCurrentDeposit) - (newBalanceCurrentWidthdraw + 15.0));//calculation
				} else {//else
					return newBalanceCurrent = (balance + overdraftLimit) - (newBalanceCurrentWidthdraw - newBalanceCurrentDeposit);//calculation
				}
			}
	
}