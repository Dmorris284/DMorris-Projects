/* Author: David Morris
ID:201084474
Program: Bank Account Management Program
Purpose: the purpose of this program is to create a simple bank account system to allow a user to view,
deposit and widthdraw values in the account, of which there are 3 types of accounts, basic, current,
and savings. then the program will display the details on screen to the user.
*/

public class BankAccountBasic {//class
	
	protected double balance = 0.0;//variable
	
	public BankAccountBasic(){//construtor

	}
}