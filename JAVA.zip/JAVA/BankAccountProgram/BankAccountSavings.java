/* Author: David Morris
ID:201084474
Program: Bank Account Management Program
Purpose: the purpose of this program is to create a simple bank account system to allow a user to view,
deposit and widthdraw values in the account, of which there are 3 types of accounts, basic, current,
and savings. then the program will display the details on screen to the user.
*/

public class BankAccountSavings extends BankAccountBasic {//class
	
	protected double newBalanceSavings = 0.0;//variable
	
	public BankAccountSavings(double wis, double des){//constructor
		widthdrawAmountSavings = wis;
		depositAmountSavings = des;
		balanceCalc();//method call
		widthdrawCalc();//method  call
		depositCalc();//method  call
		newBalanceCalc();//method  call
	}
	
	private double widthdrawAmountSavings = 0.0;//variable
	private double depositAmountSavings = 0.0;//variable
	private double newBalanceSavingsWidthdraw = 0.0;//variable
	private double newBalanceSavingsDeposit = 0.0;//variable
	
		public double getBalanceS(){//get method
			return balance;
		}	
		
		public double getNewBalanceS(){//get method
			return newBalanceSavings;
		}		
			
			
			public double balanceCalc(){//method
				return balance;
			}
			
			public double widthdrawCalc(){//method
				System.out.printf("You have withdrawn from your savings account: $%.2f\n", widthdrawAmountSavings); //message
				return newBalanceSavingsWidthdraw = balance - widthdrawAmountSavings;//calculation
			}
				
			public double depositCalc(){
				System.out.printf("You have Deposited into your savings account: $%.2f\n", depositAmountSavings); //method
				return newBalanceSavingsDeposit = balance + depositAmountSavings;//calculation
			}
				
			public double newBalanceCalc(){//method
				return newBalanceSavings = balance + (newBalanceSavingsWidthdraw + newBalanceSavingsDeposit);//calculation
			}
}