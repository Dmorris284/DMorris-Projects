/* Author: David Morris
ID:201084474
Program: Bank Account Management Program
Purpose: the purpose of this program is to create a simple bank account system to allow a user to view,
deposit and widthdraw values in the account, of which there are 3 types of accounts, basic, current,
and savings. then the program will display the details on screen to the user.
*/

import java.util.*;

public class BankAccountInput{//class
	
	
	
	public static void main (String[]args){//main method
		
		double widthdrawAmountCurrent = 0.0;//variable
		double depositAmountCurrent = 0.0;//variable
		double widthdrawAmountSavings = 0.0;//variable
		double depositAmountSavings = 0.0;//variable
		
		BankAccountCurrent current = new BankAccountCurrent(widthdrawAmountCurrent, depositAmountCurrent);
		BankAccountSavings savings = new BankAccountSavings(widthdrawAmountSavings, depositAmountSavings);
		
		System.out.println("Welcome to the bank account deposit and widthdrawl program: ");//message
		System.out.println("Here are the Current Account Details: ");//message(current)
		System.out.println("Holder of the account: David Morris");//name
		System.out.println("Account ID: 56654");//accountId
		System.out.println("Account Balance: " + current.getBalanceC());//balance
		System.out.println("Overdraft amount: " + current.getOverdraft());//overdraft
		System.out.println("is a debit card linked with this account: " + current.getDebitCard());//debitcard
		System.out.println("account fee: $15.00");//account fee
		
		System.out.println("Here are the Savings Account Details: ");//message(savings)
		System.out.println("Holder of the account: David Morris");//name
		System.out.println("Account ID: 201554");//accountid
		System.out.println("Account Balance: " + savings.getBalanceS());//balance
		System.out.println("Interest Rate: 0.3");//interest		
		
		Scanner input = new Scanner (System.in);
		System.out.println("Please Enter the amount you would like to widthdraw from the Current Account: ");//message
		widthdrawAmountCurrent = input.nextDouble();//widthdraw input value
		System.out.println("Please enter the amount you would like to deposit into the Current Account: ");//message
		depositAmountCurrent = input.nextDouble();//deposit input value
		System.out.println("Please Enter the amount you would like to widthdraw from the Savings Account: ");//message
		widthdrawAmountSavings = input.nextDouble();//widthdraw input value
		System.out.println("Please enter the amount you would like to deposit into the Savings Account: ");//message
		depositAmountSavings = input.nextDouble();//deposit input value
		System.out.println("Here are the new Details for your Accounts: ");//message
		
		BankAccountCurrent currentNew = new BankAccountCurrent(widthdrawAmountCurrent, depositAmountCurrent);
		BankAccountSavings savingsNew = new BankAccountSavings(widthdrawAmountSavings, depositAmountSavings);
		
		System.out.println("Here are the new Current Account Details: ");//message(currentNew)
		System.out.println("Holder of the account: David Morris");//name
		System.out.println("Account ID: 56654");//accountId
		System.out.println("Account Balance: " + currentNew.getNewBalanceC());//balance(NEW)
		System.out.println("Overdraft amount: " + currentNew.getOverdraft());//overdraft
		System.out.println("is a debit card linked with this account: " + currentNew.getDebitCard());//debitcard
		System.out.println("account fee: $15.00");//account fee
		
		System.out.println("Here are tthe new Savings Account Details: ");//message(savings)
		System.out.println("Holder of the account: David Morris");//name
		System.out.println("Account ID: 201554");//accountid
		System.out.println("Account Balance: " + savingsNew.getNewBalanceS());//balance(NEW)
		System.out.println("Interest Rate: 0.3");//interest
	
	
	
	}
	
}