//Author: David Morris
//Date: 03/11/2015
//Program: Robot Movement
//Program Purpose: This program is used to calculate how long a robot is goig to move
// along and angles line where the user inputs the direction and the length of time
// the robot will be travelling.

public class RobotMovementCalc{
	
	public RobotMovementCalc(double tim, double ang){
		angle = ang;
		time = tim;
		distanceCalc();
		sinAngleCalc();
		cosAngleCalc();
		horizontalCalc();
		verticalCalc();
		batteryUseCalc();
	}
	
	private double distance = 0.0;
	private double time = 0.0;
	private double angle = 0.0;
	private double cosAngle = 0.0;
	private double sinAngle = 0.0;
	private double sinAngleDeg = 0.0;
	private double cosAngleDeg = 0.0;
	private double batteryUse = 0.0;
	private double horizontalDis = 0.0;
	private double verticalDis = 0.0;
	
	
		public double getDistance(){
			return distance;
		}
		
		public double getBatteryUse(){
			return batteryUse;
		}
		
		public double getHorizontalDis(){
			return horizontalDis;
		}
		
		public double getVerticalDis(){
			return verticalDis;
		}
			
			public double distanceCalc(){
				return distance = time*1.5;
			}

			public double sinAngleCalc(){
				return sinAngleDeg = Math.sin(angle);
			}
			
			public double cosAngleCalc(){
				return cosAngleDeg = Math.cos(angle);
			}
	
			public double horizontalCalc(){
				return horizontalDis = distance*sinAngleDeg;
			}
	
			public double verticalCalc(){
				return verticalDis = distance*cosAngleDeg;
			}
			
			/*public double cosConversion(){
				return cosAngleDeg = Math.toDegrees(cosAngle);
			}
			
			public double sinConversion(){
				return sinAngleDeg = Math.toDegrees(sinAngle);
			}*/
	
			public double batteryUseCalc(){
				return batteryUse = time*2.7;
			}
	
	
	
	
}