//Author: David Morris
//Date: 03/11/2015
//Program: Robot Movement
//Program Purpose: This program is used to calculate how long a robot is goig to move
// along and angles line where the user inputs the direction and the length of time
// the robot will be travelling.

import java.util.*;

public class RobotMovementInput{
	double time = 0;
	double angle = 0;
	
	public static void main (String[]args){
		Scanner input = new Scanner(System.in);
		System.out.println("Welcome to the Robot Movement calculation Program\n");
		System.out.println("The robot moves at a steady speed of 1.5m/s");
		System.out.println("Please input the amount of time you would like the robot to travel for:");
		double time = input.nextDouble();
		System.out.println("Please input the angle of the direction between 0-90 degrees, that you would like the robot to travel:");
		double angle = input.nextDouble();
		System.out.println("Here are the parameters that the robot has travelled:");
		
		RobotMovementCalc robot = new RobotMovementCalc(time, angle);
		System.out.println("Distance Traveled by the robot:" + robot.getDistance());
		System.out.println("Horizontal distance from start point:" + robot.getHorizontalDis());
		System.out.println("Vertical Distance from start point:" + robot.getVerticalDis());
		System.out.println("Battery life used during travel (in idle battery life seconds):" + robot.getBatteryUse());
	}
}