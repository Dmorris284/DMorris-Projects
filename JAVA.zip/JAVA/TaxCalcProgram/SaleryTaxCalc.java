/* Author: David Morris
ID:201084474
Program: Salery and tax Calculation Program
Purpose: The purpose of this program is to calculate the tax value for a salary depending
on the salaries size. And then display to the user what thier salery is, the tax amount and 
the net salery after tax has been deducted.
*/

public class SaleryTaxCalc{
	
	public SaleryTaxCalc(double sal, double inc, double tim){
		baseSalary = sal;
		percentIncrease = inc;
		yearsTime = tim;
		grossSalCalc();
		taxSalCalc();
		netSalCalc();	
	}
	
	private double baseSalary;
	private double percentIncrease;
	private double yearsTime;
	private double grossSal = 0.0;
	private double tax = 0.0;
	private double netSal = 0.0;
	
		public double getGrossSalCalc(){
			return GrossSalCalc;
		}
	
		public double getTaxSalCalc(){
			return taxSalCalc;
		}
	
		public double getNetSalCalc(){
			return netSalCalc;
		}
	
			public double grossSalCalc(){
				return grossSal = (baseSalary * (yearsTime - 1) + ((baseSalary * (yearsTime - 1) * percentIncrease / 100);
			}
	
			public double taxSalCalc(){
				if (grossSal <= 30000){
					return tax = grossSal * 20 / 100;
				} else {
					return tax = (30000 * 20 / 100) + ((grossSal - 30000) * 50 / 100);
				}
			}
	
			public double netSalCalc(){
				return netSal = grossSal - tax;
			}		
	
}