/* Author: David Morris
ID:201084474
Program: Salery and tax Calculation Program
Purpose: The purpose of this program is to calculate the tax value for a salary depending
on the salaries size. And then display to the user what thier salery is, the tax amount and 
the net salery after tax has been deducted.
*/

import java.util.*;

public class SaleryTaxInput{
	double baseSalary = 0;
	double percentIncrease = 0;
	double yearsTime = 0;
	
	public static void main (String[]args){
		Scanner input = new Scanner (System.in);
		System.out.println("This is the salary and tax calculation program, please enter your details:");
		System.out.println("Please enter your base salary amount: ");
		double baseSalary = input.nextDouble();
		while (baseSalary <= 0){
			printf("Error, input is not a valid value, please re-enter the details: ");
			double baseSalery = input.nextDouble();
		}
		System.out.println("Please enter the percent increase for your salary: ");
		double percentIncrease = input.nextDouble();
		while (percentIncrease < 0, > 100){
			printf("Error, input is not a valid value, please re-enter the details: ");
			double percentIncrease = input.nextDouble();
		}
		System.out.println("please enter the yearly time of your increase: ");
		double yearsTime = input.nextDouble();
		while (yearsTime <= 0){
			printf("Error, input is not a valid value, please re-enter the details: ");
			double yearsTime = input.nextDouble();
		}
		
	SaleryTaxCalc salary = new SaleryTaxCalc(baseSalery, percentIncrease, yearsTime);
	System.out.println("The Base Salary Pay is: " + baseSalary);
	System.out.println("The Gross Salary Pay is: " + salary.getGrossSalCalc());
	System.out.println("The Tax amount is: " + salary.getTaxSalCalc());
	System.out.println("The Net Salary Amount is: " + salary.getNetSalCalc());
	}
	
}