import java.util.*;
import java.net.*;
import java.io.*;

/**
the client class handles all user input and send it to the server using threads
it also recieves data coming in from the server using a thread.
**/
public class ClientClass{//class for client input and output
	
		String serverID = "127.0.0.1";//variable for IP address for server
		int portNumber = 9001;//variable for the port number to connect to
		String userName = "";//variable for username
		boolean validUser = true;//variable to see if user is valid
	
	/**
	this method starts the client functions hand basically connects the sockets 
	then passes the sockets to the threads to handle I/O.
	**/
	public void start(){//start main process of program
		//starts the client program
		try{//try to do this
			//********************************************************************************
		//	userNameInput();
			
			System.out.println("Connecting user to " + serverID + " on port " + portNumber);//message on screen
			Socket clientUser = new Socket(serverID, portNumber);//creates an object so client can connect to handller
			ClientInputThread inputThread = new ClientInputThread(clientUser);
			ClientOutputThread outputThread = new ClientOutputThread(clientUser);
			inputThread.start();
			outputThread.start();

		} catch(IOException e){//catch thhis probllem 
			System.out.println(e);//print error on screen
		}
	}	
}

/**
this class is about the client recieving data from the server.
**/
class ClientInputThread extends Thread{
	
	Socket inputThread;
	PrintWriter printW;
	BufferedReader bufferR;
	String recievedMessage = "";
	boolean clientConnected = false;//variable to see if user is connected
	
	/**
	the constructor connects the sockets for the client to the server.
	**/
	public ClientInputThread(Socket iFromServer){
		try{
			inputThread = iFromServer;
			
			InputStream is = inputThread.getInputStream();//gets socket for recieveing message
			InputStreamReader isr = new InputStreamReader(is);//passes socket to object
			bufferR = new BufferedReader(isr);//makes oject to ppass infor to server
			
		} catch(Exception e){
			System.out.println(e);
		}
	}
	
	/**
	this method reads the lines from the server and displayes them on the user screen
	**/
	public void run(){
		
		while(true){
			try{
				if(clientConnected == false){
				System.out.println("Please Enter Username to Continue:");
				clientConnected = true;
				}
				
				if((recievedMessage = bufferR.readLine()) != null){
					
					System.out.println(recievedMessage);//displays what server said to user
					
				}
				
			} catch(Exception e){
				e.printStackTrace();
			}
		}
	}	
}

/**
this class is about the user input and sending the messages to the server
**/
class ClientOutputThread extends Thread{
	
	Socket outputThread;
	PrintWriter printW;
	BufferedReader bufferR;
	String clientMessage = "";//variable for client message
	
	/**
	the constructor sets up the socket from the client to the server.
	**/
	public ClientOutputThread(Socket oToServer){
		try{
			outputThread = oToServer;
			
			OutputStream os = outputThread.getOutputStream();//gets socket for  user to message
			OutputStreamWriter osw = new OutputStreamWriter(os);//passes socket to object
			printW = new PrintWriter(osw);//makes an object so cliennt can send messages to the hanndler
		
		} catch(Exception e){
			System.out.println(e);
		}
	}
	
	/**
	this method acquires the input form the user and sends it to ther server.
	**/
	public void run(){
		while(true){
			try{
						
				Scanner input = new Scanner(System.in);//scans for user input
				clientMessage = input.nextLine();//client message equals what is read from the userinput on the last line
				clientMessage = clientMessage + "\n";//add new line to end previous line
						
				printW.print(clientMessage);//prints out client message
				printW.flush();
				
			} catch(Exception e){
				System.out.println(e);
			}	
		}
	}	
}