import java.util.*;
import java.net.*;
import java.io.*;

/**
this class is where the client instance starts so all clients
will start with this class.
**/
public class ClientMain{//main class for the client
	
	/**
	The main method in this class creates an object for the client instance
	then call the run method from that class.
	**/
	public static void main (String[]args){//main method intiates client program
		
		ClientClass client = new ClientClass();//create an object to link classes
		client.start();//method call from other class
		
	}
}
