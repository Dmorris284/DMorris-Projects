import java.util.*;
import java.net.*;
import java.io.*;

/**
the server class is the main server that makes the sockets that are needed for the client to connect to
**/
public class ServerClass{
	
	/**
	the main method in this class links the sockest from the client
	and the server then starts the handler class to handle I/O.
	**/
	public static void main(String[]args){//main method for server program
		int portNumber = 9001;//set the port number for the server to use
		try{
		serverSocket = new ServerSocket(portNumber);//new object
		} catch(Exception e){
			System.out.print(e);
		}
		while(true){//while the server is on
			try{//try to do this
				//*****************************************************************************
				//client connection
				
				System.out.println("Waiting for client on port number " + serverSocket.getLocalPort() + "...");//client connecting
				Socket clientCon = serverSocket.accept();//client socket
				ServerHandler handler = new ServerHandler(clientCon);//handler overtake of socket
				client.add(handler);//adds handler to hash set
				handler.start();//run handler function
				
			}catch(Exception e){//if above doesnt work then catch error
				System.out.println(e);//print error on screen
				break;//break from the loop
			}
		}
		
	}
	
	private static ServerSocket serverSocket;//create object
	public static HashSet <ServerHandler> client = new HashSet <ServerHandler>();//hashset to contain all client threads so multiple can connect
}

/**
the handler class deals with I/O from the clients and a new handler is made whenever a new client
enters the server chat room.
**/
class ServerHandler extends Thread{//new class for handlers
	
	Socket handler;//variable for socket
	boolean clientConnected = false;//variable for boolean
	String userName = "";//variable for string
	String serverOutput = "";//varable for string
	PrintWriter printW;
	BufferedReader bufferR;
	String clientMessage = "";//set variable
	HashSet client;
	String msg = "";
	
	/**
	this constructor connects the sockets and allows I/O to pass through it.
	**/
	public ServerHandler(Socket clientHandler){//constructor
		try{
			handler = clientHandler;//socket is passed to the handler
				
			OutputStream os = handler.getOutputStream();//gets socket for output use
			OutputStreamWriter osw = new OutputStreamWriter(os);//allows the handler to write from the stream
			printW = new PrintWriter(osw);//gives an object that can write to the client
			
			InputStream is = handler.getInputStream();//gets the socket for the handler to send info to
			InputStreamReader isr = new InputStreamReader(is);//allows the socket to read inpuut from the user
			bufferR = new BufferedReader(isr);//creates an object that can send messages
			
		} catch(Exception e){
			System.out.println(e);
		}	
	}
	
	/**
	the run method deals with the user I/O and has parameters that decid what to do with the
	user input depending if it has a command fucntion. as well as calling the methods to acquire the username
	for the user.
	**/
	public void run(){//run method
		
		while(true){//while the server is on
			try{//try to do this
				//***********************************************************************
				//recieve from client, send to server 

				if(clientConnected == false){//if the client is not connnected
					System.out.println("CLIENT CONNECTED: " + handler);//message
					usernameAquisition();//call username method
					getConnectVerification();//set that the user is connected
				} 
				
				clientMessage = bufferR.readLine();//the client message is equal to the text that is read on the line
				System.out.println(userName + " sent: " + clientMessage);
				//****************************************************************************************
				//this determines what the handler does with the message it has been sent from the client
				
				if(clientMessage == "END_SESSION"){
					//GIVE NOTIFICATION THAT USER IS ENDING SESSION
					System.out.println("END SESSION");
				} else if(clientMessage == "SERVER_IP_ADDRESS"){
					//GIVE SERVER IP ADDRESS TO CLIENT
					System.out.println("SERVER IP ADDRESS");
				} else if(clientMessage == "GIVE_CLIENT_AMOUNT"){
					//GIVE CLIENT THE TOTAL NUMBER OF CLIENTS IN SERVER
					System.out.println("CLIENT NUMBER");
				} else if(clientMessage == "COMMAND_LIST"){
					//GIVE CLIENT THE COMMAND LIST TO ENTER COMMANDS
					System.out.println("COMMAND LIST ");
				} else if(clientMessage == "SERVER_RUNTIME"){
					//GIVE TOTAL RUNTIME OF SERVER
					System.out.println("SERVER RUNTIME");
				} else if(clientMessage == "CHAT_RUNTIME"){
					//GIVE TOTAL RUNTIME OF CHATROOM
					System.out.println("CHAT RUNTIME");
				} else {
					//broadcastMethod();
				}
				
			}catch(IOException e){//if this error
				System.out.println(e);//print this
				break;//break from the loop
			}
		}	
	}
	
	/**
	this method handles the aquisition for the username so the user will have one to use
	in the chat room.
	**/
	public void usernameAquisition(){//username method
		while(userName == ""){//while the username is blank
			try{
				userName = bufferR.readLine();//username equals what the user wrote on the previous line
				//if (username == <ServerHandler>){
					//userName = "";
				//} else {
					//break;
					//System.out.println("userName is: " + userName);
				//}
			} catch(Exception e){
				System.out.println(e);
			}	
		}
	}
	
	/**
	this method sets the clientConnected value to true so it doesnt loop certain times
	in the program.
	**/
	public void getConnectVerification(){//method
		clientConnected = true;//set clientConnected to true
	}
	
}