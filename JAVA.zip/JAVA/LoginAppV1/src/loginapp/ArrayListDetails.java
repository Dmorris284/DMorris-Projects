/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginapp;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import static loginapp.LoginApp.record;

/**
 *
 * @author dmorris7
 */
public class ArrayListDetails {

    boolean passwordok = false;//this sets the boolean value for checking to see if the username and passwords match. 
    boolean usernameok = true;

    ArrayList<PersonDetails> myArray
            = new ArrayList();
    PersonDetails record;

    public void add(PersonDetails myRecord) {
              System.out.println( " named record " + myRecord.getName()) ;
        myArray.add(myRecord);//this is where the program gets the stored name and validates it to what the user inputted
    }

    public PersonDetails getRecord(int index) {
        return (myArray.get(index));
    }

    public int GetSize() {
        return (myArray.size());//this gets the variable for the formula below
    }

    public boolean searchRecord(String name, String password) {
        for (int count = 0; count < myArray.size(); count++) {
            record = (PersonDetails) myArray.get(count);
            String nameStored = (String) record.getName();
                        String passwordStored = (String) record.getPassword();//this gets the password that was stored in "record"  
                       System.out.println(name + " named stored " + nameStored) ;//and validates it to what the user inputted.
            if (nameStored.equals(name) && passwordStored.equals(password))
            {
                passwordok = true;//if the password is ok then the program will continue
                break;
            } else if (count == myArray.size() - 1) {
                passwordok = false;//otherwise the program will say it is incorrect
                JOptionPane.showMessageDialog(null, "Name Not Found");
            }
        }
        return passwordok;
    }
}
