/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginapp;

/**
 *
 * @author dmorris7
 */
public class PersonDetails {

    //BELOW IS AN EXAMPLE OF ATTRIBUTES, THESE LOOK AND ACT THE SAME WAY AS 
    //VARIABLES, THEY ARE DECLARED AS PRIVATE.  

    private String name = "";
    private String password = "";
    private String username = "";

    // below is an example of a constructor. the constructor is used to build the class We can use 
    //the constructor to force the program to give username and password a value.
    public PersonDetails(String uName, String pWord) {
    // this line triggers the method "setusername", the method will contain a value in uName.
        // remember a method is a little piece of code, that does a particular job or task.
        
        setUsername(uName);
    //below is a method that is used to give the attribute username a value. it takes the values
        // that has been passed to name and asses this on to the username.
        setPassword(pWord);
    }

    public String getName() {
        return name;//this is where the program will retrieve the value for name that the user enters in the program
    }

    public String getPassword() {
        return password;//this is where the program will retrieve the value for password that the user enters in the program
    }

     // the mathod below is used to get the current value that is stored in username.
    // notics that the word void has been replaced with string, this represents 
    // the type of data that will be returned back to body of code that has triggered
    //this method to run. the command return is the keyword that makes the code return data back.
    public String getUsername() {
        return username;//this is where the program will retrieve the value for username that the user enters in the program
    }

    public void setName(String name) {
        this.name = name;//this is where the user will enter a valid name to be stored
    }

    public void setPassword(String password) {
         System.out.println(password+ " inside personal  password details");
        this.password = password;//this is where the user will enter a valid password to be stored
    }

    public void setUsername(String username) {
        this.username = username;//this is where the user will enter a valid username to be stored
    }

}
