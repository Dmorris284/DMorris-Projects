/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginapp;

/**
 *
 * @author david
 */
public class AreaTriangle {

    public double heightT = 0;//these are the variables that are set at the start with values of zero so that
    public double widthT = 0;//they will have a numerical value, and the user can alter these values by entering 
    public double depthT = 0;//a new numerical value that will modify this set value.
    private double AreaT;
    private double VolumeT;

    public double getTriangleHeight() {
        return heightT;//this is where the program will retrieve the value for height that the user enters in the program 
    }

    public void setTriangleHeight(double heightT1) {
        this.heightT = heightT1;//this is where the user will enter a numerical value for the height
    }                           //and this height will be put in the variable form where it can be used for the calculation

    public double getTriangleWidth() {
        return widthT;//this is where the program will retrieve the value for width that the user enters in the program 
    }

    public void setTriangleWidth(double widthT1) {
        this.widthT = widthT1;//this is where the user will enter a numerical value for the width
    }                           //and this width will be put in the variable form where it can be used for the calculation
    
    public double getTriangleDepth() {
        return depthT;//this is where the program will retrieve the value for depth that the user enters in the program 
    }

    public void setTriangleDepth(double DepthT1) {
        this.depthT = DepthT1;//this is where the user will enter a numerical value for the depth
    }                           //and this depth will be put in the variable form where it can be used for the calculation

    public double getAreaT() {
        AreaT = (widthT * heightT) * 0.5;
        return AreaT;//this is the calculation for the program that will calculate the area using the variable values set by the user
    }
    
    public double getVolumeT() {
        VolumeT = (widthT * heightT * depthT) /3;
        return VolumeT;//this is the calculation for the program that will calculate the volume using the variable values set by the user
    }
    
}
