
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginapp;

/**
 *
 * @author dmorris7
 */
public class LoginApp {

    static ArrayListDetails myArray = new ArrayListDetails();//these are used within the main class so that the other characters can intereact 
    static GuiReg guireg = new GuiReg();//with eachother and allows the program to communicate
    static GuiHelp guihelp = new GuiHelp();
    static GuiLogin guiLogin = new GuiLogin();//these variables are all static so they cannot be changed or modified anywhere else
    static GuiCalc guicalc = new GuiCalc();//other than the class they are declared in.
    static int state = 0;
    static PersonDetails record;
    static AreaRectangle areaRect = new AreaRectangle();
    static AreaCircle areaCirc = new AreaCircle();
    static AreaTriangle areaTri = new AreaTriangle();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                changeScreen();
            }
        });
        myRecord();

// TODO code application logic here
    }

    public static void changeScreen() {
        if (state == 0) {
            guiLogin.setVisible(true);//this sets the boolean values of all of the Gui screens depending on what state 
            guireg.setVisible(false);//the change screen is on
            guicalc.setVisible(false);
            guihelp.setVisible(false);
        } else if (state == 1) {
            guireg.setVisible(true);
            guiLogin.setVisible(false);
            guicalc.setVisible(false);
            guihelp.setVisible(false);
        } else if (state == 2) {
            guireg.setVisible(false);
            guiLogin.setVisible(false);
            guihelp.setVisible(false);
            guicalc.setVisible(true);
        } else if (state == 3) {
            guireg.setVisible(false);
            guiLogin.setVisible(false);
            guicalc.setVisible(false);
            guihelp.setVisible(true);
        
        }
    }

    public static void myRecord() {
  record    = new PersonDetails("", "");//this means that the record can be set with 2 values one or password
    }                                   //and one for username, these values willl then be stores in "record"

    public PersonDetails getRecord() {

        return record;//this returns the record from the array list so it can be stored.
    }

}
