/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginapp;

/**
 *
 * @author david
 */
public class AreaCircle {

    public double radius = 0;//these are the variables that are set at the start with values of zero so that
    private double AreaC;//they will have a numerical value, and the user can alter these values by entering
    private double VolumeC;//a new numerical value that will modify this set value.

    public double getCircleRadius() {
        return radius;//this is where the program will retrieve the value for the radius that the user enters in the program
    }

    public void setCircleRadius(double radius1) {
        this.radius = radius1; //this is where the user will enter a numerical value for the radius
    }                           //and this radius will be put in the variable form where it can be used for the calculation

    public double getAreaC() {
        AreaC = 3.14 * (radius * radius);
        return AreaC;//this is the calculation for the program that will calculate the area using the variable values set by the user
    }
    
    public double getVolumeC() {
        VolumeC = (4/3 * 3.14) * (radius * radius * radius);
        return VolumeC;//this is the calculation for the program that will calculate the volume using the variable values set by the user
    }
}
