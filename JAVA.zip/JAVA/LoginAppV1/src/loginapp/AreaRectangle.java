/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginapp;


/**
 *
 * @author david
 */
public class AreaRectangle {

    public double width = 0;//these are the variables that are set at the start with values of zero so that
    public double height = 0;//they will have a numerical value, and the user can alter these values by entering
    public double depth = 0;//a new numerical value that will modify this set value.
    private double AreaR;
    private double VolumeR;

    public double getRectangleHeight() {
        return height;//this is where the program will retrieve the value for height that the user enters in the program
    }

    public void setRectangleHeight(double height1) {
        this.height = height1;//this is where the user will enter a numerical value for the height
    }                           //and this height will be put in the variable form where it can be used for the calculation

    public double getRectangleWidth() {
        return width;//this is where the program will retrieve the value for width that the user enters in the program
    }

    public void setRectangleWidth(double width1) {
        this.width = width1;//this is where the user will enter a numerical value for the width
    }                       //and this width will be put in the variable form where it can be used for the calculation
    
    public double getRectangleDepth() {
        return depth;//this is where the program will retrieve the value for depth that the user enters in the program
    }

    public void setRectangleDepth(double Depth1) {
        this.depth = Depth1;//this is where the user will enter a numerical value for the depth
    }                       //and this depth will be put in the variable form where it can be used for the calculation

    public double getAreaR() {
        AreaR = width * height;
        return AreaR;//this is the calculation for the program that will calculate the area using the variable values set by the user
    }
    
    public double getVolumeR() {
        VolumeR = width * height * depth;
        return VolumeR;//this is the calculation for the program that will calculate the volume using the variable values set by the user
    }

}
