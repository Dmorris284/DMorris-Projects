/* Author: David Morris
ID:201084474
Program: this program is a game that 2 players take part in, a human player and a 
computer player. the user upon startup can select which type of 
computer player to play against. The players then take it in turns to select an attribute
on a card that each of them is holding, once attributes are selected they compare the values
of them and the winner takes the other players card and adds it to thier deck.
the process is repeated untill on player has all the cards of thier opponents deck
*/

import java.util.*;

	/**
	This class holds the information for the cards and is where the game accesses them.
	*/
public class CardClass{//class
	
	String name;
	AttributeClass attributes;
		
	/**
	The constructor creates a new instance of attributes and name for the game class to refer to.
	*/
	public CardClass(){//constructor
		
		attributes = new AttributeClass();
		name = attributes.attributeName;
	}
	
}