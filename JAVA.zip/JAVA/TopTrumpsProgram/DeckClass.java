/* Author: David Morris
ID:201084474
Program: 
Purpose: 
*/

import java.util.*;

public class DeckClass{//class
	
}