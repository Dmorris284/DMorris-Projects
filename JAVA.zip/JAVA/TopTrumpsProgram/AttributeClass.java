/* Author: David Morris
ID:201084474
Program: this program is a game that 2 players take part in, a human player and a 
computer player. the user upon startup can select which type of 
computer player to play against. The players then take it in turns to select an attribute
on a card that each of them is holding, once attributes are selected they compare the values
of them and the winner takes the other players card and adds it to thier deck.
the process is repeated untill on player has all the cards of thier opponents deck
*/

import java.util.*;

	/**
	this class is responsible for holding the attributes and which cards have what attributes.
	it holds these pieces of info in a series of arrays.
    */
public class AttributeClass{//class

	public static int noOfAttributes = 10;
	
	public static String [] nameArray = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"};
	public static int [] speedArray = {3,7,1,3,1,1,6,7,8,2};
	public static int [] weightArray = {4,8,6,2,4,9,8,1,4,6};
	public static int [] sizeArray = {1,2,3,6,9,4,3,2,1,7};
	public static int [] costArray = {3,4,7,6,3,8,7,1,9,6};
	public static int [] handlingArray = {1,5,9,5,3,8,6,2,8,4};
	
	String attributeName = "not set";
	int attributeSpeed = 0;
	int attributeWeight = 0;
	int attributeSize = 0;
	int attributeCost = 0;
	int attributeHandling = 0;

	/**
	this method shows that there can only be a set number of cards in each deck to start with so each deck has the same amount fo cards.
    */
	public AttributeClass(){
		
		if (noOfAttributes <= 0) {
			
			attributeName = "n/a";
			attributeSpeed = -1;
			attributeWeight = -1;
			attributeSize = -1;
			attributeCost = -1;
			attributeHandling = -1;
			
		} else {
			
			attributeName = nameArray[noOfAttributes-1];
			attributeSpeed = speedArray[noOfAttributes-1];
			attributeWeight = weightArray[noOfAttributes-1];
			attributeSize = sizeArray[noOfAttributes-1];
			attributeCost = costArray[noOfAttributes-1];
			attributeHandling = handlingArray[noOfAttributes-1];
		}
		
		--noOfAttributes;
	}

	/**
	this method @returns the value for the number of attributes.
    */
	public static int getAttributesLeft () {
		
		return noOfAttributes;
	}

	/**
	this method acquires the largest possible valued attribute among a single card. 
	this is primarily used for the complex computer player.
    */
	public int getMaxAttribute () {
		
		int max = 0;
		
		if (attributeSpeed > max)
			max = attributeSpeed;
		if (attributeWeight > max)
			max = attributeWeight;
		if (attributeSize > max)
			max = attributeSize;
		if (attributeCost > max)
			max = attributeCost;
		if (attributeHandling > max)
			max = attributeHandling;
		
		return max;
	}
}






