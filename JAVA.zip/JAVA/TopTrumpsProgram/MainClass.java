/* Author: David Morris
ID:201084474
Program: this program is a game that 2 players take part in, a human player and a 
computer player. the user upon startup can select which type of 
computer player to play against. The players then take it in turns to select an attribute
on a card that each of them is holding, once attributes are selected they compare the values
of them and the winner takes the other players card and adds it to thier deck.
the process is repeated untill on player has all the cards of thier opponents deck.
*/

/**
Main method - used to enter the program on startup.
*/

import java.util.*;

/**
The Main method initialises the program by calling the primary game method from another class.
*/
public class MainClass{//class
	
	public static void main (String[]args){//main method
	
		GameClass game = new GameClass();
		game.start();
	}
	
	
}



