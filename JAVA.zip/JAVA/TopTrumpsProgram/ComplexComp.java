/* Author: David Morris
ID:201084474
Program: this program is a game that 2 players take part in, a human player and a 
computer player. the user upon startup can select which type of 
computer player to play against. The players then take it in turns to select an attribute
on a card that each of them is holding, once attributes are selected they compare the values
of them and the winner takes the other players card and adds it to thier deck.
the process is repeated untill on player has all the cards of thier opponents deck 
*/

import java.util.*;

	/**
	This class is one of the computer players that can be played in the game.
	It extends from the Player class and inherits certain aspects from that class.
	*/
public class ComplexComp extends PlayerClass{//class
	
	/**
	This method states that it is a computer player and that it is not human.
	*/
	public ComplexComp(){//constructor
		this.name = "Computer";
		isHuman = false;
	}
	
	/**
	This method confirms that the name is name. 
	*/
	public ComplexComp(String name){//constructor
		this.name = name;
		isHuman = false;
	}
	
	/**
	This method is how the computer selects which attribute to use on its turn.
	since this is the complex computer player it always picks the highest available attribute value.
    */
	public void playerTurn(){//method
		
		selectedAttribute = drawCard().attributes.getMaxAttribute();
	}
	
	
}