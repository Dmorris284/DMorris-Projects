/* Author: David Morris
ID:201084474
Program: this program is a game that 2 players take part in, a human player and a 
computer player. the user upon startup can select which type of 
computer player to play against. The players then take it in turns to select an attribute
on a card that each of them is holding, once attributes are selected they compare the values
of them and the winner takes the other players card and adds it to thier deck.
the process is repeated untill on player has all the cards of thier opponents deck 
*/

import java.util.*;	

	/**
	this is one of the classes that extend from the player class as this class has information specifically for human players.
    */
public class HumanClass extends PlayerClass{//class
	
	/**
	this method states that the player is human and sets a default name for the user.
    */
	public HumanClass(){
		this.name = "not set";
		isHuman = true;
	}

	/**
	this method gives name a purpose and allows the user to override the default name.
    */
	public HumanClass(String name){
		this.name = name;
		isHuman = true;
	}
	
	private int userInput = 0;
	private boolean validInput = false;
	
	/**
	this method checks to see if the user input is valid, if it is then it continues, otherwise the user must re-enter the values until they input a valid answer.
	@param of this method is the user input.
    */
	public void playerTurn(){//method
		
		boolean validInput = false;
		Scanner input = new Scanner(System.in);
		
		while (validInput == false){
			System.out.println("");//input message
			userInput = input.nextInt();
			
			if (userInput <= 0){
				System.out.println("Input too low");//error message
				userInput = input.nextInt();
			}
			
			else if (userInput > 5){
				System.out.println("Input too high");//error message
				userInput = input.nextInt();
			}
			
			else{
				validInput = true;
				selectedAttribute = userInput;
			}
		}
	}
}







