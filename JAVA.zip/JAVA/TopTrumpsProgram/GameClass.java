/* Author: David Morris
ID:201084474
Program: this program is a game that 2 players take part in, a human player and a 
computer player. the user upon startup can select which type of 
computer player to play against. The players then take it in turns to select an attribute
on a card that each of them is holding, once attributes are selected they compare the values
of them and the winner takes the other players card and adds it to thier deck.
the process is repeated untill on player has all the cards of thier opponents deck
*/

import java.util.*;
	/**
	this class is the primary class where everything links to.
	as this method has the workings for the game. 
    */
public class GameClass{//class
	
	boolean gameOver = false;
	int playerTurn = 1;
	boolean userWonRound = false;
	int userPickedAttribute = 0;
	int compPickedAttirbute = 0;
	int aiChosen = 0;
	
	private Scanner input = new Scanner(System.in);
	
	private HumanClass human;
	private PlayerClass computer;
	
	/**
	the constructor in this class aquires user input for thier name and the selection for which Ai to play against in the game.
    */
	public GameClass(){// constructor
		String response = "";
		System.out.println("Please enter name:");
		response = input.next();
		
		human = new HumanClass(response);
		
		System.out.println("Select 1 for Simple Opponent");
		System.out.println("Select 2 for Random Opponent");
		System.out.println("Select 3 for Expert Opponent");
		
		while(aiChosen == 0){
		
			aiChosen = input.nextInt();
			
			if(aiChosen == 1){
				
				System.out.println("You are Against the Simple Opponent\n");
				computer = new SimpleCompClass();
			
			} else if(aiChosen == 2){
				
				System.out.println("You are Against the Random Opponent\n");
				computer = new RandomComp();
				
			} else if(aiChosen == 3){
				
				System.out.println("You are Against the Complex Opponent\n");
				computer = new ComplexComp();
				
			} else {
				
				System.out.println("Invalid Entry, Please Try Again.");
				aiChosen = input.nextInt();
				
			}
		}
		
		while (AttributeClass.getAttributesLeft() > 5) {
			CardClass card = new CardClass();
			human.playerDeck.add(card);
		}
		
		while (AttributeClass.getAttributesLeft() > 0) {
			CardClass card = new CardClass();
			computer.playerDeck.add(card);
		}
	}

	/**
	this is the primary game method that is initialised by the main method.
	this method starts by a loop that checks to see a winner at the start of each game turn.
	after that it determines the game turn and what occurs on each turn.
	after that it determines who loses a card and who wins one.
	then it changes the game turn.
    */
	public void start(){
				
		while (gameOver == false) { //game loop
		
			// Check for a winner ***************************************
			
			if (computer.emptyDeck()) {
				
				System.out.println("Player '" + human.name + "' wins!!!");
				gameOver = true;
				
			} else if (human.emptyDeck()) {
				
				System.out.println("Player '" + computer.name + "' wins!!!");
				gameOver = true;
			}
		
			if (playerTurn == 1){
				
				System.out.println("It's " + human.name + " turn:"); // DEBUG
				
				System.out.println("   Card:     " + human.drawCard().attributes.attributeName);
				System.out.println("(1)Speed:    " + human.drawCard().attributes.attributeSpeed);
				System.out.println("(2)Weight:   " + human.drawCard().attributes.attributeWeight);
				System.out.println("(3)Size:     " + human.drawCard().attributes.attributeSize);
				System.out.println("(4)Cost:     " + human.drawCard().attributes.attributeCost);
				System.out.println("(5)Handling: " + human.drawCard().attributes.attributeHandling);
				
				human.playerTurn();
				computer.selectedAttribute = human.selectedAttribute;
				System.out.println("\n" + human.name + " has " + human.getAttributeValue());
				System.out.println(computer.name + " has " + computer.getAttributeValue() + "\n");
				
			} else {
				
				System.out.println("It's " + computer.name + "'s turn:"); // DEBUG
				
				computer.playerTurn();
				human.selectedAttribute = computer.selectedAttribute;
				
				System.out.println("\n" + computer.name + " has " + computer.getAttributeValue());
				System.out.println(human.name + " has " + human.getAttributeValue() + "\n");
			}
			
			if (human.getAttributeValue() > computer.getAttributeValue()) {
				
				System.out.println(human.name + " wins this round...\n"); // DEBUG
					
				userWonRound = true;
				CardClass losingCard = computer.drawCard();
				computer.playerDeck.remove(losingCard);
				human.playerDeck.add(losingCard);
				
			} else {
				
				System.out.println(computer.name + " wins this round...\n"); // DEBUG
				
				userWonRound = false;
				CardClass losingCard = human.drawCard();
				human.playerDeck.remove(losingCard);
				computer.playerDeck.add(losingCard);
			}

			// Change turns ***************************************
			
			if (playerTurn == 1){
				
				playerTurn++;//add 1 to player turn
				
			} else {
				
				playerTurn--;//subtract 1 from player turn
			}
			
		}
		
	}
}