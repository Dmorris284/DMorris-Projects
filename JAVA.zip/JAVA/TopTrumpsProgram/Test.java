/* Author: David Morris
ID:201084474
Program: 
Purpose: 
*/

import java.util.*;

public class Test{//class
	
	public static void main (String[]args){//main method
	
		for (int i = 0; i < 50; ++i) {
			System.out.println(((int)(Math.random() * 5) + 1));
		}
	}
	
	
}