/* Author: David Morris
ID:201084474
Program: this program is a game that 2 players take part in, a human player and a 
computer player. the user upon startup can select which type of 
computer player to play against. The players then take it in turns to select an attribute
on a card that each of them is holding, once attributes are selected they compare the values
of them and the winner takes the other players card and adds it to thier deck.
the process is repeated untill on player has all the cards of thier opponents deck 
*/

import java.util.*;	

	/**
	this class is the parent class of the types of players in this program.
    */
public abstract class PlayerClass{//class
	
	protected String name = "";
	protected boolean isHuman = false;
	protected int selectedAttribute = 0;
	
	protected ArrayList<CardClass> playerDeck = new ArrayList<CardClass>();
	
	protected abstract void playerTurn();
	
	/**
	This method checks to see if the deck is full and if it is then it will return true for the game to end otherwise it will continue the game.
    */
	public boolean fullDeck(){
		if (playerDeck.size() >= 20) {
			return true;
		} else {
			return false;
		}
	}

	/**
	This method checks to see if the deck is empty and if it is then it will return true for the game to end otherwise it will continue the game.
    */	
	public boolean emptyDeck(){
		if (playerDeck.size() <= 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	this is the method for how the user will draw cards from thier deck.
    */	
	public CardClass drawCard(){
		return playerDeck.get(0);
	}

	/**
	this method takes the user input and determines which attribute was selected.
	@param of this method is the user input.
    */
	public int getAttributeValue(){
		if(selectedAttribute == 1){
			return this.drawCard().attributes.attributeSpeed;
		} else if(selectedAttribute == 2){
			return this.drawCard().attributes.attributeWeight;
		} else if(selectedAttribute == 3){
			return this.drawCard().attributes.attributeSize;
		} else if(selectedAttribute == 4){
			return this.drawCard().attributes.attributeCost;
		} else if(selectedAttribute == 5){
			return this.drawCard().attributes.attributeHandling;
		} else {
			System.out.println("Invalid input");//error message
			return -1;
		}
	}
}







