/* Author: David Morris
ID:201084474
Program: 
Purpose: 
*/

 import java.util.*;

public class GameProgramInput{//class
	
	public static void main (String[]args){//main method 
		int playerOneInput = 0;//variable
		int playerTwoInput = 0;//variable
		int playerTurn = 1;//variable
		int winner = 0;//variable
		boolean positionValid = false;//variable
		boolean gameOver = false;//variable
	
		Scanner input = new Scanner(System.in);//allows input
		System.out.println("Welcome to the 2 player game");//welcome message
		System.out.println("the game is to get a 2x2 square of your number before the other player.");//welcome message
		GameProgramCalc game = new GameProgramCalc();

		while (gameOver == false) {//while loop
			
			if (playerTurn == 1) {//if statement
				game.takePlayerOneInput();//get player one input
			} else {//else
				game.takePlayerTwoInput();//get player 2 input
			}
			
			game.displayGrid();//method call
			
			winner = game.checkWin();//method call
			if (winner == 1) {//if statement
				gameOver = true;//variable change
				System.out.printf("Player %d wins!\n", winner);//message
			} else if (winner == 2) {//else if statement
				gameOver = true;//variable change statement
				System.out.printf("Player %d wins!\n", winner);//message
			}
			
			
			if (playerTurn == 1) {//if statement
				playerTurn++;//add 1 to player turn
			} else {//else
				playerTurn--;//take away 1 from player turn
			}
		}
	}
}