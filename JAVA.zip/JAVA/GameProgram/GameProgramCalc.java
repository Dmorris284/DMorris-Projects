/* Author: David Morris
ID:201084474
Program: 
Purpose: 
*/

import java.util.*;

public class GameProgramCalc{//class
	
	public int [][] arrayInput = new int [5][5];//array
	
	public GameProgramCalc(){//constructor
		
		// Initialise array
		for (int row = 0; row < 5; row++) {//for loop 
			for (int col = 0; col < 5; col++) {//for loop 
				arrayInput[row][col] = 0;
			}
		}
	}
	
	private int playerOneInput = 0;//variable
	private int playerTwoInput = 0;//variable
	private boolean positionValid = false;//variable
	private boolean gameOver = false;//variable
	
		public void getTakePlayerOneInput(){//get method
			takePlayerOneInput();//method call
		}
		
		public void getTakePlayerTwoInput(){//get method
			takePlayerTwoInput();//method call
		}
		
		public void getCheckWin(){//get method
			checkWin();//method call
		}
		
			public void takePlayerOneInput(){//method
				
				boolean positionValid = false;//variable
				Scanner input = new Scanner(System.in);//allows input
				
				while (positionValid == false){//while loop
						
					System.out.println("Player 1 please input the position of your move: ");//playerOneInput
					playerOneInput = input.nextInt();//input
					while (playerOneInput <= 0){//while loop
						System.out.println("Error, input is not a valid value, please re-enter: ");//message
						playerOneInput = input.nextInt();//input
					}
					while (playerOneInput > 25){//while loop
						System.out.println("Error, input is not a valid value, please re-enter: ");//message
						playerOneInput = input.nextInt();//input
					}
					
					int x = (playerOneInput - 1) / 5;
					int y = (playerOneInput - 1) % 5;
					
					if (arrayInput[x][y] == 0) {//if statement for user to know which number they can overwrite
						arrayInput[x][y] = 1;//replace zero with this
						positionValid = true;//change boolean value
					} else {//else statement
						System.out.println("INVALID INPUT, PLEASE TRY AGAIN: ");//message
					}
				}
			}
			
			public void takePlayerTwoInput(){//method
				
				boolean positionValid = false;//variable
				Scanner input = new Scanner(System.in);//allows input
				
				while (positionValid == false){//while loop
						
					System.out.println("Player 2 please input the position of your move: ");//playerTwoInput
					playerTwoInput = input.nextInt();//input
					while (playerTwoInput <= 0){//while loop
						System.out.println("Error, input is not a valid value, please re-enter: ");//message
						playerTwoInput = input.nextInt();//input
					}
					while (playerTwoInput > 25){//while loop
						System.out.println("Error, input is not a valid value, please re-enter: ");//message
						playerTwoInput = input.nextInt();//input
					}
					
					int x = (playerTwoInput - 1) / 5;
					int y = (playerTwoInput - 1) % 5;
					
					if (arrayInput[x][y] == 0) {//if statement for user to know which number they can overwrite
						arrayInput[x][y] = 2;//replace zero with this
						positionValid = true;//change boolean value
					} else {//else statement
						System.out.println("INVALID INPUT, PLEASE TRY AGAIN: ");//message
					}
				}
			}
			
			public int checkWin () {//method
				
				for (int row = 0; row < 4; row++){//for loop 1
					for (int col = 0; col < 4; col++){
						if((arrayInput[row][col] == 1) && (arrayInput[row + 1][col] == 1)) {//if statement 1
							if((arrayInput[row][col + 1] == 1) && (arrayInput[row + 1][col + 1] == 1)){//if statement 2
								return 1;
							}//end of if statement 2
						}//end of if statement 1
					}//end of for loop 2
				}//end of for loop 1
				for (int row = 0; row < 4; row++){//for loop 3
					for (int col = 0; col < 4; col++){//for loop 4
						if((arrayInput[row][col] == 2) && (arrayInput[row + 1][col] == 2)) {// if statement 3
							if((arrayInput[row][col + 1] == 2) && (arrayInput[row + 1][col + 1] == 2)){//if statement 4
								return 2;
							}//end of if statement 4
						}//end of if statement 3
					}//end of for loop 4
				}//end of for loop 3
				return 0;
			}
			
			public void displayGrid () {//method
				
				for (int row = 0; row < 5; row++) {//for loop
					for (int col = 0; col < 5; col++) {//for loop
						System.out.printf("%d ", arrayInput[row][col]);//displays the grid
					}
					System.out.printf("\n");//new line
				}
			}
}











