/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package polymorphism;

/**
 *
 * @author dmorris7
 */   
public class Polymorphism {
static Animal animals= new Cat();
static Animal animals1= new Dog(); 
static Animal animals2= new Duck();
         
static Animal animal[] = new Animal[3];//this is an array as it uses the square brackets
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
            animal[0] = new Cat ();//this is a polymorphic object as it is both
            animal[1] = new Dog ();//Animal and Cat. 
            animal[2] = new Duck ();
             
            for (int count = 0; count <3; count++){
                 animal[count].sounds();
            }
            acceptAnimal (animals);
            acceptAnimal (animals1);  
            acceptAnimal (animals2);
         }
         public static void acceptAnimal (Animal randAn)
         {
             randAn.sound();
         }
    }
        // TODO code application logic here       
