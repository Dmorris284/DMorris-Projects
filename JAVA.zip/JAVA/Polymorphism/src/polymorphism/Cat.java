/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package polymorphism;

/**
 *
 * @author dmorris7
 */
public class Cat extends Animal{// example of inheritance
     
        protected void sound(){
            System.out.println("Meow version 1");//this is overriding the default response for this action.          
        }
        
         protected void sounds(){
            System.out.println("Meow version 2");                   
        }
}
