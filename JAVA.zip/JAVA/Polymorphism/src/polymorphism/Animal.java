/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package polymorphism;

/**
 *
 * @author dmorris7
 */
public class Animal {//encapsulation is where code is hidden so that it is 
    
     protected void sound() {
            System.out.println("Animals make noise");//override means that the 
                                                     //default noise is overridden by the animals
                                                     //specific noise
        }
        protected void sounds() {
            System.out.println("Meow version 2");
        }
}
