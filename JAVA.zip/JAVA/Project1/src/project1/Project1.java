/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

/**
 *
 * @author dmorris7
 */
public class Project1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println(1+1);
                
        System.out.println("1"+"1");
                
        System.out.println(1.16+1.26);
                
        System.out.println("1.16"+"1.26");
                        
        System.out.println("hello"+"\n"+"dave");
        
        System.out.println("hello"+"\n"+"dave"+"\t"+"josh"+"\t"+"duncan");
         
        int numOne = 4; 
        int numTwo = 2;
        
        
        System.out.println(numOne+numTwo);
        System.out.println(numOne*numTwo);
        System.out.println(numOne/numTwo);
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Gui().setVisible(true);
            }
        });
        
    }
    
    
    
}


